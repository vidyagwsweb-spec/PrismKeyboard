# Prism Keyboard (Android)

A native Android Input Method Editor (IME) starter app with a translucent, iOS-inspired visual treatment.

## Included
- Native Android keyboard service (works as a system keyboard once enabled)
- Translucent gradient keyboard surface and rounded keys
- English QWERTY layout, emoji panel, punctuation, space and enter
- Device speech-recognition handoff for voice typing
- Basic local autocorrection for a small set of common typos
- Prefix-based word suggestions
- Translation handoff to Google Translate (selected text, or the word before the cursor)

## Build
Open this folder in Android Studio (Giraffe or newer), allow Gradle sync, then Build > Build Bundle(s) / APK(s) > Build APK(s).

## Enable on Android
1. Install the generated APK.
2. Open Prism Keyboard and tap **Enable Prism Keyboard**.
3. Enable Prism Keyboard in Android's input-method settings.
4. Tap **Select Prism Keyboard** and choose it.

## Honest limitations
This is a functional first build, not a Gboard replacement yet. Autocorrect and suggestions use a small bundled word list, not a full language model. Translation opens Google Translate rather than translating offline inside the keyboard. Voice recognition depends on a speech-recognition provider installed on the device. Android may show its standard keyboard privacy warning when enabling any third-party IME.
