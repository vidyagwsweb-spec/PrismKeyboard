package com.spheman.prismkeyboard

import android.inputmethodservice.InputMethodService
import android.content.*
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.view.*
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputConnection
import android.widget.*
import android.os.Build

class PrismImeService : InputMethodService() {
    private lateinit var root: LinearLayout
    private lateinit var suggestionBar: LinearLayout
    private var emojiMode = false
    private var shift = true
    private val typed = StringBuilder()
    private val corrections = mapOf("teh" to "the", "adn" to "and", "thier" to "their", "recieve" to "receive", "becuase" to "because", " dont" to " don't", " i " to " I ")
    private val words = listOf("the", "that", "this", "there", "their", "then", "think", "thanks", "hello", "how", "have", "what", "when", "where", "with", "you", "your", "you're", "are", "and", "for", "from", "good", "great", "please", "because", "about")
    private val voiceReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            val result = intent?.getStringExtra("text") ?: return
            currentInputConnection?.commitText(result, 1)
        }
    }

    override fun onCreate() {
        super.onCreate()
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(voiceReceiver, IntentFilter("com.spheman.prismkeyboard.VOICE_RESULT"), RECEIVER_NOT_EXPORTED)
        else @Suppress("DEPRECATION") registerReceiver(voiceReceiver, IntentFilter("com.spheman.prismkeyboard.VOICE_RESULT"))
    }
    override fun onDestroy() { try { unregisterReceiver(voiceReceiver) } catch (_: Exception) {}; super.onDestroy() }

    override fun onCreateInputView(): View = buildKeyboard()
    override fun onStartInput(attribute: EditorInfo?, restarting: Boolean) { super.onStartInput(attribute, restarting); typed.clear() }

    private fun buildKeyboard(): View {
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(8, 9, 8, 10); background = glassBackground() }
        suggestionBar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(2, 0, 2, 5) }
        root.addView(suggestionBar, LinearLayout.LayoutParams(-1, 42))
        updateSuggestions()
        if (emojiMode) addEmojiKeys() else {
            addRow(listOf("q","w","e","r","t","y","u","i","o","p"))
            addRow(listOf("a","s","d","f","g","h","j","k","l"), 8)
            addRow(listOf("⇧","z","x","c","v","b","n","m","⌫"))
            val bottom = LinearLayout(this).apply { gravity = Gravity.CENTER; orientation = LinearLayout.HORIZONTAL }
            bottom.addView(key("?123", 0xFFCBD2E1.toInt()) { insert("?123") }, lp(0.14f))
            bottom.addView(key("😊", 0xFFCBD2E1.toInt()) { emojiMode = true; setInputView(buildKeyboard()) }, lp(0.12f))
            bottom.addView(key("🎙", 0xFFCBD2E1.toInt()) { startActivity(Intent(this, VoiceActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }, lp(0.12f))
            bottom.addView(key(",", 0xFFCBD2E1.toInt()) { insert(",") }, lp(0.09f))
            bottom.addView(key("English · Translate", 0xFFF8FAFF.toInt()) { translateSelection() }, lp(0.23f))
            bottom.addView(key("space", Color.WHITE) { insert(" ") }, lp(0.38f))
            bottom.addView(key(".", 0xFFCBD2E1.toInt()) { insert(".") }, lp(0.09f))
            bottom.addView(key("↵", 0xFFB8C5E5.toInt()) { currentInputConnection?.sendKeyEvent(android.view.KeyEvent(android.view.KeyEvent.ACTION_DOWN, android.view.KeyEvent.KEYCODE_ENTER)); currentInputConnection?.sendKeyEvent(android.view.KeyEvent(android.view.KeyEvent.ACTION_UP, android.view.KeyEvent.KEYCODE_ENTER)) }, lp(0.12f))
            root.addView(bottom, LinearLayout.LayoutParams(-1, 52))
        }
        return root
    }

    private fun addRow(keys: List<String>, side: Int = 0) {
        val row = LinearLayout(this).apply { gravity = Gravity.CENTER; orientation = LinearLayout.HORIZONTAL }
        if (side > 0) row.setPadding(side, 0, side, 0)
        keys.forEach { label -> row.addView(key(label) { when(label) { "⇧" -> { shift = !shift; setInputView(buildKeyboard()) }; "⌫" -> delete(); else -> insert(if (shift) label.uppercase() else label) } }, LinearLayout.LayoutParams(0, 49, 1f).apply { setMargins(3, 3, 3, 4) }) }
        root.addView(row, LinearLayout.LayoutParams(-1, 52))
    }

    private fun addEmojiKeys() {
        val emojis = listOf("😀","😂","🥹","😍","😎","😭","🔥","❤️","👍","🙏","✨","💀","🥳","🤔","😊","🎉","💯","🌈","🚀","💖","😴","🙌","🤝","😅","🤩","😇","👏","💀","🫶","😈")
        val grid = GridLayout(this).apply { columnCount = 6 }
        emojis.forEach { e -> val b = key(e) { currentInputConnection?.commitText(e, 1) }; grid.addView(b, GridLayout.LayoutParams().apply { width = 0; height = 48; columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f); setMargins(2,2,2,2) }) }
        root.addView(grid, LinearLayout.LayoutParams(-1, 210))
        root.addView(key("ABC   Close emoji panel") { emojiMode = false; setInputView(buildKeyboard()) }, LinearLayout.LayoutParams(-1, 45))
    }

    private fun key(label: String, color: Int = Color.WHITE, action: () -> Unit): TextView = TextView(this).apply {
        text = label; textSize = if (label.length > 4) 12f else 20f; gravity = Gravity.CENTER; setTextColor(0xFF202638.toInt()); typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        background = GradientDrawable().apply { setColor(color); cornerRadius = 13f; setStroke(1, 0x66FFFFFF) }
        elevation = 2f; isClickable = true; isFocusable = true; setOnClickListener { action() }
    }
    private fun lp(weight: Float) = LinearLayout.LayoutParams(0, 48, weight).apply { setMargins(2, 1, 2, 1) }
    private fun glassBackground() = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(0xE9F1F5FF.toInt(), 0xE4E2E9F7.toInt(), 0xE9F7F0F8.toInt())).apply { cornerRadii = floatArrayOf(22f,22f,22f,22f,0f,0f,0f,0f); setStroke(1, 0xAAFFFFFF.toInt()) }

    private fun insert(s: String) {
        val ic = currentInputConnection ?: return
        if (s == " ") {
            val before = ic.getTextBeforeCursor(40, 0)?.toString().orEmpty()
            val token = before.takeLastWhile { !it.isWhitespace() }
            val fixed = corrections[token.lowercase()]
            if (fixed != null) { ic.deleteSurroundingText(token.length, 0); ic.commitText(fixed, 1) }
            ic.commitText(" ", 1); typed.clear()
        } else { ic.commitText(s, 1); if (s.length == 1 && s[0].isLetter()) typed.append(s.lowercase()) }
        updateSuggestions()
    }
    private fun delete() { currentInputConnection?.deleteSurroundingText(1, 0); if (typed.isNotEmpty()) typed.deleteCharAt(typed.length - 1); updateSuggestions() }
    private fun updateSuggestions() {
        if (!::suggestionBar.isInitialized) return
        suggestionBar.removeAllViews()
        val before = currentInputConnection?.getTextBeforeCursor(30, 0)?.toString().orEmpty()
        val prefix = before.takeLastWhile { it.isLetter() }.lowercase()
        val candidates = if (prefix.length >= 2) words.filter { it.startsWith(prefix) && it != prefix }.take(3) else listOf("✨", "Translate", "Settings")
        candidates.forEach { candidate ->
            val v = TextView(this).apply { text = candidate; textSize = 15f; gravity = Gravity.CENTER; setTextColor(0xFF273149.toInt()); setPadding(12, 3, 12, 3); setOnClickListener { if (candidate == "Translate") translateSelection() else if (candidate == "Settings") startActivity(Intent(this@PrismImeService, SetupActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) else { val n = prefix.length; currentInputConnection?.deleteSurroundingText(n, 0); currentInputConnection?.commitText(candidate, 1) } } }
            suggestionBar.addView(v, LinearLayout.LayoutParams(0, -1, 1f))
        }
    }
    private fun translateSelection() {
        val selected = currentInputConnection?.getSelectedText(0)?.toString().orEmpty().ifBlank { currentInputConnection?.getTextBeforeCursor(100, 0)?.toString()?.takeLastWhile { !it.isWhitespace() }.orEmpty() }
        if (selected.isBlank()) { Toast.makeText(this, "Select text or place the cursor after a word", Toast.LENGTH_SHORT).show(); return }
        val uri = Uri.parse("https://translate.google.com/?sl=auto&tl=en&text=" + Uri.encode(selected) + "&op=translate")
        startActivity(Intent(Intent.ACTION_VIEW, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }
}
