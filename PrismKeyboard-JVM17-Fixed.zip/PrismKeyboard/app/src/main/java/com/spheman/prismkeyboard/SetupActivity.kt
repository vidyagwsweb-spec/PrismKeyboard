package com.spheman.prismkeyboard

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.*
import android.graphics.Color

class SetupActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(28, 36, 28, 36); setBackgroundColor(0xFFF3F5FA.toInt()) }
        val title = TextView(this).apply { text = "Prism Keyboard"; textSize = 30f; setTextColor(0xFF202638.toInt()); gravity = Gravity.CENTER; setPadding(0,0,0,12) }
        val subtitle = TextView(this).apply { text = "A translucent Android keyboard."; textSize = 16f; setTextColor(0xFF657089.toInt()); gravity = Gravity.CENTER; setPadding(0,0,0,28) }
        val enable = Button(this).apply { text = "1. Enable Prism Keyboard"; setOnClickListener { startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)) } }
        val choose = Button(this).apply { text = "2. Select Prism Keyboard"; setOnClickListener { val imm = getSystemService(INPUT_METHOD_SERVICE) as android.view.inputmethod.InputMethodManager; imm.showInputMethodPicker() } }
        val note = TextView(this).apply { text = "Voice typing uses your device's speech recognition. Translation opens Google Translate. Prism does not collect or store what you type."; textSize = 13f; setTextColor(0xFF69738A.toInt()); gravity = Gravity.CENTER; setPadding(8,24,8,0) }
        layout.addView(title); layout.addView(subtitle); layout.addView(enable); layout.addView(choose); layout.addView(note)
        setContentView(layout)
    }
}
