# Glass Keys (Android keyboard)

## Build on GitHub (no Android Studio needed)
1. Push this folder to a GitHub repo (branch `main`).
2. Open the repo's **Actions** tab > **Build APK** (it runs on every push; or click *Run workflow*).
3. When it finishes, download **GlassKeys-debug-apk** from the run's Artifacts, unzip it, and install `app-debug.apk`.
4. Tag a commit `v1.0` to also get the APK attached to a GitHub Release.

## Build locally
Open in Android Studio (Koala or newer) > Build > Build APK(s).
APK: app/build/outputs/apk/debug/app-debug.apk

## Setup on the phone
Open Glass Keys and follow the 3 setup buttons.

## What's new in 1.1
- Real vector icons for shift, caps lock, backspace, enter/search/send/done, mic, emoji, clipboard, globe, etc. (no more unicode glyphs for UI symbols).
- Key sound on every key press (follows the phone's ringer mode and system volume). Speaker button in the tools row turns it on/off.
- Restyled to the iOS-style light glass keyboard: letters-only layout (123 key for numbers, #+= for more symbols), white rounded keys, translucent function keys, predictions bar with dividers, globe and mic below the keys. Long-press the predictions bar for clipboard / translate / sound.
- Frosted-glass keyboard: on Android 12+ (with window blur enabled) the keyboard background blurs whatever is behind it and the translucent keys sit on top of that blur. Older phones get a more opaque tint.
- Better suggestions: ranked by your own words and word pairs (stored only on the device), then common words, then the full dictionary.
- Safer autocorrect: bundled ~127k-word dictionary (`res/raw/words.txt`). Only fixes a word when it is unknown and exactly one edit away from a clearly better common word. It never touches names, ALL CAPS, accented words, handles/URLs or words typed in the middle of existing text. Backspace right after a correction undoes it and teaches the keyboard the word.
- Long-press any character key for accents / symbols / fractions. Slide to pick, release to insert. Also: space = switch keyboard, shift = caps lock, enter = new line, emoji key = clipboard.

## 1.2 changes
- Overlay mode: the keyboard tells the app it takes no layout space, so the app's content stays full height and shows through the blurred glass (toggle: long-press the predictions bar, then the layers icon, if an app hides the text field).
- Long-press popup is now anchored to the pressed key, so it appears above it.
- Tighter key spacing; `,` and `.` keys sit next to the space bar.
- Real translate icon; return key morphs between return, arrow (send/go/next/search) and checkmark (done).

## 1.3 changes
- Dark mode. The keyboard (and the setup screen) follow the system light/dark setting and switch live when it changes.
- New typing sound: two short clicks cut from a recording (`res/raw/key_tap.wav` for letters, `key_tap_low.wav` for space, delete, enter and other function keys), played a bit softer than full volume. Swap those files to change the sound.
