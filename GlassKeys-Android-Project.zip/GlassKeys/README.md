# Glass Keys (Android keyboard)

## Build on GitHub (no Android Studio needed)
1. Push this folder to a GitHub repo (branch `main`).
2. Open the repo's **Actions** tab > **Build APK** (it runs on every push; or click *Run workflow*).
3. When it finishes, download **GlassKeys-debug-apk** from the run's Artifacts, unzip it, and install `app-debug.apk`.
4. Tag a commit `v1.0` to also get the APK attached to a GitHub Release.

## Build locally
Open in Android Studio (Koala or newer) > Build > Build APK(s).
APK: app/build/outputs/apk/debug/app-debug.apk

## Setup on the phone
Open Glass Keys and follow the 3 setup buttons.
