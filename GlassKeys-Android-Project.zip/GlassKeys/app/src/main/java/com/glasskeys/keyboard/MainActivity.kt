package com.glasskeys.keyboard

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.inputmethod.InputMethodManager
import android.widget.*

class MainActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val d = resources.displayMetrics.density
        val dark = (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
        val ink = if (dark) Color.WHITE else 0xFF1C1C1E.toInt()
        val hintColor = if (dark) 0x99FFFFFF.toInt() else 0x991C1C1E.toInt()
        fun dp(v: Int) = (v * d).toInt()
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(24), dp(56), dp(24), dp(32))
        }
        fun glass(a: Int): GradientDrawable {
            val boost = if (dark) 0 else 110
            return GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(Color.argb(minOf(a + 30 + boost, 255), 255, 255, 255), Color.argb(minOf(a + boost, 255), 255, 255, 255))).apply {
                cornerRadius = dp(16).toFloat()
                setStroke(dp(1), if (dark) Color.argb(80, 255, 255, 255) else Color.argb(120, 255, 255, 255))
            }
        }
        fun label(t: String, sp: Float, bold: Boolean = false) = TextView(this).apply {
            text = t; textSize = sp; setTextColor(ink)
            if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
            setPadding(0, dp(4), 0, dp(10))
        }
        fun btn(t: String, go: () -> Unit) = Button(this).apply {
            text = t; isAllCaps = false; setTextColor(ink); textSize = 16f
            background = glass(50)
            layoutParams = LinearLayout.LayoutParams(-1, dp(54)).apply { bottomMargin = dp(12) }
            setOnClickListener { go() }
        }
        box.addView(label("Glass Keys", 30f, true))
        box.addView(label("Set up your keyboard in three taps.", 16f))
        box.addView(btn("1. Enable Glass Keys") { startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)) })
        box.addView(btn("2. Switch to Glass Keys") {
            (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker()
        })
        box.addView(btn("3. Allow microphone for voice typing") { askMic() })
        box.addView(btn("4. Show screenshots in the clipboard") { askPhotos() })
        val test = EditText(this).apply {
            hint = "Try it here…"; setHintTextColor(hintColor); setTextColor(ink)
            background = glass(30); setPadding(dp(16), dp(14), dp(16), dp(14)); gravity = Gravity.TOP
            minLines = 3
        }
        box.addView(test)
        setContentView(ScrollView(this).apply {
            isFillViewport = true
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR,
                if (dark) intArrayOf(0xFF1C2B52.toInt(), 0xFF4B2A7B.toInt(), 0xFF0E7C9B.toInt())
                else intArrayOf(0xFFCFE0FF.toInt(), 0xFFE2D4FA.toInt(), 0xFFC4ECF5.toInt()))
            addView(box)
        })
        if (intent.getBooleanExtra("ask_mic", false)) askMic()
        if (intent.getBooleanExtra("ask_photos", false)) askPhotos()
    }

    private fun askPhotos() {
        val perm = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_IMAGES else Manifest.permission.READ_EXTERNAL_STORAGE
        if (checkSelfPermission(perm) == PackageManager.PERMISSION_GRANTED)
            Toast.makeText(this, "Screenshots already allowed", Toast.LENGTH_SHORT).show()
        else requestPermissions(arrayOf(perm), 2)
    }

    private fun askMic() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED)
            Toast.makeText(this, "Microphone already allowed", Toast.LENGTH_SHORT).show()
        else requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 1)
    }

    override fun onRequestPermissionsResult(rc: Int, p: Array<out String>, r: IntArray) {
        super.onRequestPermissionsResult(rc, p, r)
        val ok = r.firstOrNull() == PackageManager.PERMISSION_GRANTED
        val msg = if (rc == 2) (if (ok) "Screenshots will show in the clipboard" else "Screenshots need photo access")
                  else (if (ok) "Voice typing is ready" else "Voice typing needs the microphone")
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    }
}
