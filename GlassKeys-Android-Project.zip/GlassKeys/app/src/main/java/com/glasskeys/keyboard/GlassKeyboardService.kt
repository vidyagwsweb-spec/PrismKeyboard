package com.glasskeys.keyboard

import android.Manifest
import android.content.ClipboardManager
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.StateListDrawable
import android.inputmethodservice.InputMethodService
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.text.Html
import android.text.InputType
import android.text.TextUtils
import android.view.*
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputConnection
import android.widget.*
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.Locale
import kotlin.concurrent.thread

private const val WORDS = "the be to of and a in that have I it for not on with he as you do at this but his by from they we say her she or an will my one all would there their what so up out if about who get which go me when make can like time no just him know take people into year your good some could them see other than then now look only come its over think also back after use two how our work first well way even new want because any these give day most us hello hi hey thanks thank please sorry yes okay ok yeah great awesome love happy tomorrow today tonight morning night later soon meet call text message send phone home friend friends family dinner lunch coffee tired busy free late early sure maybe really very much many more less here where why while been being were was is are am did does done doing going gone coming don't can't it's that's what's let's you're I'm I've won't didn't doesn't isn't wasn't need needs help thing things something nothing everything everyone someone anyone place week weekend month years always never often again still already should must might around before between through during without within find found tell told ask asked feel felt keep kept let begin start started stop try tried talk talked turn turned run ran walk move live lived believe hold bring brought happen happened write wrote provide sit stand lose pay paid meet include continue set learn change lead understand watch follow create speak read allow add spend grow open walk win offer remember consider appear buy wait serve die send expect build stay fall cut reach kill remain suggest raise pass sell require report decide pull school work job money car book game food water music movie phone computer email number name question answer idea problem story woman man child girl boy mother father brother sister party birthday congratulations welcome definitely probably actually because beautiful important different another little right wrong best better worst bad nice fine cool fun funny long short big small old young hot cold hard easy ready sorry"
private val FIXES = mapOf(
    "i" to "I", "im" to "I'm", "i'm" to "I'm", "ive" to "I've", "i've" to "I've", "i'll" to "I'll", "i'd" to "I'd",
    "dont" to "don't", "cant" to "can't", "wont" to "won't", "didnt" to "didn't", "doesnt" to "doesn't",
    "isnt" to "isn't", "wasnt" to "wasn't", "couldnt" to "couldn't", "wouldnt" to "wouldn't",
    "shouldnt" to "shouldn't", "youre" to "you're", "thats" to "that's", "whats" to "what's",
    "lets" to "let's", "theyre" to "they're", "arent" to "aren't", "havent" to "haven't",
    "teh" to "the", "recieve" to "receive", "definately" to "definitely", "thier" to "their",
    "wierd" to "weird", "tommorow" to "tomorrow", "seperate" to "separate", "alot" to "a lot",
    "becuase" to "because", "freind" to "friend", "wich" to "which", "adn" to "and"
)
private val NEXT = mapOf(
    "i" to listOf("am", "will", "have"), "i'm" to listOf("not", "going", "so"),
    "thank" to listOf("you", "you so", "goodness"), "thanks" to listOf("for", "so", "a"),
    "how" to listOf("are", "to", "much"), "what" to listOf("is", "are", "do"),
    "see" to listOf("you", "the", "if"), "good" to listOf("morning", "night", "luck"),
    "have" to listOf("a", "to", "been"), "going" to listOf("to", "on", "home"),
    "let" to listOf("me", "us", "you"), "do" to listOf("you", "not", "it"),
    "are" to listOf("you", "we", "they"), "you" to listOf("are", "can", "have"),
    "the" to listOf("best", "same", "first"), "to" to listOf("be", "the", "do"),
    "hello" to listOf("there", "everyone", "!"), "see you" to listOf("soon", "later", "tomorrow")
)
private val EMOJI = listOf(
    "🕘" to "",
    "😀" to "😀 😃 😄 😁 😆 😅 😂 🤣 😊 😇 🙂 😉 😍 🥰 😘 😋 😛 😜 🤪 🤔 🤨 😐 😏 🙄 😬 😴 😷 🥵 🥶 😎 🤓 😕 🙁 😮 😳 🥺 😢 😭 😱 😤 😡 🤬 😈 💀 🤡 👻 🤖",
    "👍" to "👍 👎 👌 ✌️ 🤞 🤟 🤘 🤙 👈 👉 👆 👇 👋 ✋ 👏 🙌 🙏 🤝 💪 ❤️ 🧡 💛 💚 💙 💜 🖤 🤍 💔 💕 💞 💓 💗 💖 💘 ✨ 🔥 💯 ✅ ❌ ⭐ 🎉",
    "🐶" to "🐶 🐱 🐭 🐹 🐰 🦊 🐻 🐼 🐨 🐯 🦁 🐮 🐷 🐸 🐵 🐔 🐧 🐦 🦉 🐺 🐴 🦄 🐝 🦋 🐢 🐍 🐙 🐬 🐳 🌸 🌹 🌻 🌲 🌴 🌵 🍀 🌍 🌙 ☀️ 🌈 ❄️ ⚡ 🌊",
    "🍔" to "🍎 🍊 🍋 🍌 🍉 🍇 🍓 🍒 🥭 🍍 🥑 🍅 🥕 🌽 🥔 🍞 🧀 🍳 🥓 🍔 🍟 🍕 🌭 🌮 🍝 🍜 🍣 🍱 🍦 🍩 🍪 🎂 🍰 🍫 🍿 ☕ 🍵 🥤 🍺 🍷 🥂 🍹",
    "⚽" to "⚽ 🏀 🏈 ⚾ 🎾 🏐 🎱 🏓 🥊 🎯 ⛳ 🎮 🎲 🧩 🎨 🎬 🎤 🎧 🎸 🎹 🥁 📚 ✈️ 🚗 🚕 🚌 🚲 🚀 🚢 🏠 🏖️ ⛺ 🗽 🏰 🎡 🏆 🥇 🎁 🎈 🎊",
    "💡" to "📱 💻 ⌨️ 📷 🔋 💡 📺 ⏰ ⌛ 💰 💳 💎 🔧 🔨 🔑 🔒 📌 📎 ✏️ 📝 📅 📧 📦 🛒 🎒 👑 👓 👟 👗 💄 🧸 🔔 🔍 🚨 ⚠️ ♻️ 💬 💭 🔗 ➡️ 🔄"
)
private val LANGS = listOf(
    "Español" to "es", "Français" to "fr", "Deutsch" to "de", "Italiano" to "it", "Português" to "pt",
    "हिन्दी" to "hi", "العربية" to "ar", "中文" to "zh-CN", "日本語" to "ja", "한국어" to "ko",
    "Русский" to "ru", "Türkçe" to "tr", "English" to "en"
)

class GlassKeyboardService : InputMethodService() {
    private val ui = Handler(Looper.getMainLooper())
    private val dict = WORDS.split(" ")
    private val dictLower = dict.map { it.lowercase() }
    private val dictSet = dictLower.toHashSet()
    private val learned = HashSet<String>()
    private val seen = HashMap<String, Int>()
    private val clips = ArrayList<String>()
    private val recents = ArrayList<String>()
    private lateinit var prefs: SharedPreferences
    private lateinit var cm: ClipboardManager
    private val clipListener = ClipboardManager.OnPrimaryClipChangedListener { readClip() }

    private lateinit var keysPanel: LinearLayout
    private lateinit var emojiPanel: LinearLayout
    private lateinit var emojiGrid: LinearLayout
    private lateinit var clipPanel: LinearLayout
    private lateinit var clipList: LinearLayout
    private lateinit var transPanel: LinearLayout
    private lateinit var suggestRow: LinearLayout
    private lateinit var toolRow: LinearLayout
    private lateinit var toggleBtn: TextView
    private lateinit var symKey: TextView
    private lateinit var enterKey: TextView
    private lateinit var micBtn: TextView
    private lateinit var srcView: TextView
    private lateinit var resultView: TextView
    private val sugViews = ArrayList<TextView>()
    private val sugText = arrayOf("", "", "")
    private val tabViews = ArrayList<TextView>()
    private val chipViews = ArrayList<Pair<TextView, String>>()

    private var mode = 0 // 0 keys, 1 emoji, 2 clipboard, 3 translate
    private var shift = 0 // 0 off, 1 once, 2 caps lock
    private var lastShiftTap = 0L
    private var symbols = false
    private var suggestOn = true
    private var wordMode = false
    private var undo: Pair<String, String>? = null
    private var toolsOpen = false
    private var speech: SpeechRecognizer? = null
    private var listening = false
    private var targetLang = "es"
    private var transSrcLen = 0
    private var transSelected = false
    private var transResult = ""

    // ---------- lifecycle ----------
    override fun onCreate() {
        super.onCreate()
        prefs = getSharedPreferences("glass", MODE_PRIVATE)
        learned.addAll(prefs.getStringSet("learned", emptySet()) ?: emptySet())
        prefs.getString("clips", "")?.split("\u0001")?.filter { it.isNotBlank() }?.let { clips.addAll(it) }
        prefs.getString("recents", "")?.split(" ")?.filter { it.isNotBlank() }?.let { recents.addAll(it) }
        cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
        cm.addPrimaryClipChangedListener(clipListener)
    }

    override fun onDestroy() {
        cm.removePrimaryClipChangedListener(clipListener)
        stopVoice()
        super.onDestroy()
    }

    override fun onEvaluateFullscreenMode() = false

    override fun onStartInputView(info: EditorInfo, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        if (!::keysPanel.isInitialized) return
        val t = info.inputType
        val cls = t and InputType.TYPE_MASK_CLASS
        val v = t and InputType.TYPE_MASK_VARIATION
        val blocked = listOf(
            InputType.TYPE_TEXT_VARIATION_PASSWORD, InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD,
            InputType.TYPE_TEXT_VARIATION_WEB_PASSWORD, InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS,
            InputType.TYPE_TEXT_VARIATION_WEB_EMAIL_ADDRESS, InputType.TYPE_TEXT_VARIATION_URI)
        suggestOn = cls == InputType.TYPE_CLASS_TEXT && (t and InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS) == 0 && v !in blocked
        symbols = cls == InputType.TYPE_CLASS_NUMBER || cls == InputType.TYPE_CLASS_PHONE
        enterKey.text = when (info.imeOptions and EditorInfo.IME_MASK_ACTION) {
            EditorInfo.IME_ACTION_SEARCH -> "🔍"
            EditorInfo.IME_ACTION_SEND -> "➤"
            EditorInfo.IME_ACTION_GO, EditorInfo.IME_ACTION_NEXT, EditorInfo.IME_ACTION_DONE -> "✓"
            else -> "⏎"
        }
        undo = null
        readClip()
        setMode(0)
        afterEdit(true)
    }

    override fun onFinishInputView(finishing: Boolean) {
        stopVoice()
        super.onFinishInputView(finishing)
    }

    // ---------- glass styling ----------
    private fun dp(v: Int) = (v * resources.displayMetrics.density + 0.5f).toInt()

    private fun glass(a: Int, r: Int): GradientDrawable =
        GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
            intArrayOf(Color.argb(minOf(a + 28, 255), 255, 255, 255), Color.argb(a, 255, 255, 255))).apply {
            cornerRadius = dp(r).toFloat(); setStroke(dp(1), Color.argb(70, 255, 255, 255))
        }

    private fun keyBg(a: Int = 38, r: Int = 12): Drawable = StateListDrawable().apply {
        addState(intArrayOf(android.R.attr.state_pressed), glass(130, r))
        addState(intArrayOf(), glass(a, r))
    }

    private fun accent(alpha: Int = 0xCC, r: Int = 12): Drawable {
        fun g(c1: Long, c2: Long) = GradientDrawable(GradientDrawable.Orientation.TL_BR,
            intArrayOf(c1.toInt(), c2.toInt())).apply { cornerRadius = dp(r).toFloat(); setStroke(dp(1), 0x88FFFFFF.toInt()) }
        return StateListDrawable().apply {
            addState(intArrayOf(android.R.attr.state_pressed), g(0xFFA9C8FF, 0xFFD2B0FF))
            addState(intArrayOf(), g(0x00000000L or (alpha.toLong() shl 24) or 0x6FA3FF, 0x00000000L or (alpha.toLong() shl 24) or 0xA878FF))
        }
    }

    private fun rootBg() = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
        intArrayOf(0xEE1C2B52.toInt(), 0xEE3A1F63.toInt())).apply {
        val r = dp(22).toFloat(); cornerRadii = floatArrayOf(r, r, r, r, 0f, 0f, 0f, 0f)
        setStroke(dp(1), 0x55FFFFFF)
    }

    private fun key(label: String, w: Float = 1f, size: Float = 20f, acc: Boolean = false,
                    onClick: (View) -> Unit): TextView = TextView(this).apply {
        text = label; gravity = Gravity.CENTER; setTextColor(Color.WHITE); textSize = size
        background = if (acc) accent() else keyBg()
        layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, w).apply {
            setMargins(dp(2), dp(3), dp(2), dp(3))
        }
        isClickable = true
        setOnClickListener { performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP); onClick(it) }
    }

    private fun repeatKey(label: String, w: Float, size: Float = 20f, act: () -> Unit): TextView {
        val k = key(label, w, size) { }
        val rep = object : Runnable { override fun run() { act(); ui.postDelayed(this, 50) } }
        k.setOnTouchListener { v, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    v.isPressed = true; v.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
                    act(); ui.postDelayed(rep, 400)
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> { v.isPressed = false; ui.removeCallbacks(rep) }
            }
            true
        }
        return k
    }

    private fun row() = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        layoutParams = LinearLayout.LayoutParams(-1, 0, 1f)
    }

    private fun gap(w: Float) = Space(this).apply { layoutParams = LinearLayout.LayoutParams(0, -1, w) }

    private fun note(t: String) = TextView(this).apply {
        text = t; setTextColor(0xAAFFFFFF.toInt()); textSize = 14f; gravity = Gravity.CENTER
        setPadding(dp(12), dp(24), dp(12), dp(24))
    }

    // ---------- view tree ----------
    override fun onCreateInputView(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; background = rootBg()
            setPadding(dp(4), dp(6), dp(4), dp(8))
        }
        // strip: toggle + suggestions / tools
        val strip = LinearLayout(this).apply { layoutParams = LinearLayout.LayoutParams(-1, dp(42)) }
        toggleBtn = TextView(this).apply {
            text = "▸"; textSize = 20f; gravity = Gravity.CENTER; setTextColor(Color.WHITE)
            layoutParams = LinearLayout.LayoutParams(dp(40), -1)
            setOnClickListener { toolsOpen = !toolsOpen; showTools() }
        }
        val frame = FrameLayout(this).apply { layoutParams = LinearLayout.LayoutParams(0, -1, 1f) }
        suggestRow = LinearLayout(this)
        for (i in 0..2) {
            val tv = TextView(this).apply {
                gravity = Gravity.CENTER; setTextColor(Color.WHITE); textSize = 16f
                maxLines = 1; ellipsize = TextUtils.TruncateAt.END
                layoutParams = LinearLayout.LayoutParams(0, -1, 1f)
                setOnClickListener { pick(i) }
            }
            if (i == 1) tv.setTypeface(tv.typeface, android.graphics.Typeface.BOLD)
            sugViews.add(tv); suggestRow.addView(tv)
        }
        toolRow = LinearLayout(this).apply { visibility = View.GONE }
        fun tool(label: String, act: () -> Unit) = TextView(this).apply {
            text = label; textSize = 21f; gravity = Gravity.CENTER
            layoutParams = LinearLayout.LayoutParams(0, -1, 1f); setOnClickListener { act() }
        }
        micBtn = tool("🎤") { toggleVoice() }
        toolRow.addView(tool("😊") { toggleMode(1) })
        toolRow.addView(tool("📋") { toggleMode(2) })
        toolRow.addView(tool("🌐") { toggleMode(3) })
        toolRow.addView(micBtn)
        frame.addView(suggestRow, FrameLayout.LayoutParams(-1, -1))
        frame.addView(toolRow, FrameLayout.LayoutParams(-1, -1))
        strip.addView(toggleBtn); strip.addView(frame)
        root.addView(strip)

        // panels
        val panel = FrameLayout(this).apply { layoutParams = LinearLayout.LayoutParams(-1, dp(188)) }
        keysPanel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        buildEmoji(); buildClip(); buildTranslate()
        for (p in listOf(keysPanel, emojiPanel, clipPanel, transPanel)) panel.addView(p, FrameLayout.LayoutParams(-1, -1))
        root.addView(panel)

        // bottom row
        val bottom = LinearLayout(this).apply { layoutParams = LinearLayout.LayoutParams(-1, dp(48)) }
        symKey = key("?123", 1.4f, 15f) {
            if (mode != 0) { symbols = true; setMode(0) } else { symbols = !symbols; renderKeys(); symKey.text = if (symbols) "ABC" else "?123" }
        }
        enterKey = key("⏎", 1.4f, 20f, true) { enter() }
        bottom.addView(symKey)
        bottom.addView(key(",", 1f) { type(",") })
        bottom.addView(key("😊", 1f, 19f) { toggleMode(1) })
        bottom.addView(key("Glass Keys", 4f, 12f) { space() }.also { it.setTextColor(0xAAFFFFFF.toInt()) })
        bottom.addView(key(".", 1f) { type(".") })
        bottom.addView(enterKey)
        root.addView(bottom)

        renderKeys(); setMode(0); setSug("", "", "")
        return root
    }

    private fun renderKeys() {
        keysPanel.removeAllViews()
        val up = shift > 0
        fun letter(c: Char): TextView {
            val s = if (up) c.uppercaseChar().toString() else c.toString()
            return key(s) { type(s) }
        }
        val r1 = row(); for (c in "1234567890") r1.addView(key(c.toString(), 1f, 18f) { type(c.toString()) })
        val a = if (symbols) "@#\$%&-+()/" else "qwertyuiop"
        val b = if (symbols) "_=*\"':;!?" else "asdfghjkl"
        val c3 = if (symbols) "<>[]{}|" else "zxcvbnm"
        val r2 = row(); for (c in a) r2.addView(letter(c))
        val r3 = row(); r3.addView(gap(if (symbols) 0.25f else 0.5f)); for (c in b) r3.addView(letter(c)); r3.addView(gap(if (symbols) 0.25f else 0.5f))
        val r4 = row()
        if (symbols) r4.addView(key("~", 1.5f) { type("~") })
        else r4.addView(key(if (shift == 2) "⇪" else "⇧", 1.5f, 20f, shift > 0) { onShift() })
        for (c in c3) r4.addView(letter(c))
        r4.addView(repeatKey("⌫", 1.5f) { backspace() })
        for (r in listOf(r1, r2, r3, r4)) keysPanel.addView(r)
    }

    private fun onShift() {
        val now = System.currentTimeMillis()
        shift = if (now - lastShiftTap < 350) 2 else if (shift == 0) 1 else 0
        lastShiftTap = now
        renderKeys()
    }

    private fun showTools() {
        toolRow.visibility = if (toolsOpen) View.VISIBLE else View.GONE
        suggestRow.visibility = if (toolsOpen) View.GONE else View.VISIBLE
        toggleBtn.text = if (toolsOpen) "✕" else "▸"
    }

    private fun toggleMode(m: Int) = setMode(if (mode == m) 0 else m)

    private fun setMode(m: Int) {
        mode = m
        keysPanel.visibility = if (m == 0) View.VISIBLE else View.GONE
        emojiPanel.visibility = if (m == 1) View.VISIBLE else View.GONE
        clipPanel.visibility = if (m == 2) View.VISIBLE else View.GONE
        transPanel.visibility = if (m == 3) View.VISIBLE else View.GONE
        if (m == 0) renderKeys()
        if (m == 2) refreshClips()
        if (m == 3) { srcView.text = grabSource().let { if (it.isBlank()) "Nothing to translate yet" else it.takeLast(80) }; resultView.text = ""; transResult = "" }
        symKey.text = if (m == 0 && symbols) "ABC" else "?123"
    }

    // ---------- typing ----------
    private fun isBoundary(s: String) = s.length == 1 && !s[0].isLetterOrDigit() && s[0] != '\''

    private fun type(s: String) {
        val ic = currentInputConnection ?: return
        val pending = if (isBoundary(s)) autoCorrect(ic, s) else null
        ic.commitText(s, 1)
        undo = pending
        afterEdit()
    }

    private fun space() {
        val ic = currentInputConnection ?: return
        val t = ic.getTextBeforeCursor(2, 0)?.toString() ?: ""
        if (suggestOn && t.length == 2 && t[1] == ' ' && t[0].isLetterOrDigit()) {
            ic.deleteSurroundingText(1, 0); ic.commitText(". ", 1); undo = null; afterEdit(); return
        }
        type(" ")
    }

    private fun backspace() {
        val u = undo
        if (u != null) {
            val ic = currentInputConnection ?: return
            ic.deleteSurroundingText(u.second.length, 0); ic.commitText(u.first, 1)
            learnWord(u.first.lowercase(), true); undo = null; afterEdit(); return
        }
        sendDownUpKeyEvents(KeyEvent.KEYCODE_DEL)
        afterEdit()
    }

    private fun enter() {
        val ic = currentInputConnection ?: return
        autoCorrect(ic, "")
        undo = null
        val ei = currentInputEditorInfo
        val action = ei.imeOptions and EditorInfo.IME_MASK_ACTION
        if ((ei.imeOptions and EditorInfo.IME_FLAG_NO_ENTER_ACTION) == 0 &&
            action != EditorInfo.IME_ACTION_NONE && action != EditorInfo.IME_ACTION_UNSPECIFIED)
            ic.performEditorAction(action)
        else sendDownUpKeyEvents(KeyEvent.KEYCODE_ENTER)
        afterEdit()
    }

    private fun afterEdit(force: Boolean = false) {
        val ic = currentInputConnection
        val ei = currentInputEditorInfo
        if (ic != null && ei != null && shift != 2 && !symbols && ei.inputType != 0) {
            val want = if (ic.getCursorCapsMode(ei.inputType) != 0) 1 else 0
            if (want != shift || force) { shift = want; if (mode == 0) renderKeys() }
        }
        updateSuggestions()
    }

    // ---------- autocorrect + suggestions ----------
    private fun wordBefore(ic: InputConnection): String =
        (ic.getTextBeforeCursor(30, 0)?.toString() ?: "").takeLastWhile { it.isLetter() || it == '\'' }

    private fun known(lw: String) = lw in dictSet || lw in learned

    private fun learnWord(lw: String, force: Boolean = false) {
        if (lw.length < 2 || known(lw)) return
        val n = (seen[lw] ?: 0) + 1; seen[lw] = n
        if (force || n >= 2) { learned.add(lw); prefs.edit().putStringSet("learned", learned).apply() }
    }

    private fun matchCase(w: String, fix: String): String = when {
        fix[0].isUpperCase() -> fix
        w.length > 1 && w.all { it.isUpperCase() } -> fix.uppercase()
        w[0].isUpperCase() -> fix.replaceFirstChar { it.uppercase() }
        else -> fix
    }

    private fun dist(a: String, b: String): Int {
        val d = Array(a.length + 1) { IntArray(b.length + 1) }
        for (i in 0..a.length) d[i][0] = i
        for (j in 0..b.length) d[0][j] = j
        for (i in 1..a.length) for (j in 1..b.length) {
            val c = if (a[i - 1] == b[j - 1]) 0 else 1
            d[i][j] = minOf(d[i - 1][j] + 1, d[i][j - 1] + 1, d[i - 1][j - 1] + c)
            if (i > 1 && j > 1 && a[i - 1] == b[j - 2] && a[i - 2] == b[j - 1]) d[i][j] = minOf(d[i][j], d[i - 2][j - 2] + 1)
        }
        return d[a.length][b.length]
    }

    private fun best(w: String): Pair<String, Int>? {
        var bw: String? = null; var bd = 99
        for (c in dictLower) {
            if (Math.abs(c.length - w.length) > 2) continue
            val x = dist(w, c)
            if (c[0] != w[0] && x > 1) continue
            if (x < bd) { bd = x; bw = c }
        }
        return bw?.let { it to bd }
    }

    private fun autoCorrect(ic: InputConnection, boundary: String): Pair<String, String>? {
        if (!suggestOn) return null
        val w = wordBefore(ic); if (w.isEmpty()) return null
        val lw = w.lowercase()
        var fix: String? = FIXES[lw]
        if (fix == null && lw.length >= 3 && !known(lw)) {
            val b = best(lw)
            if (b != null && b.second <= (if (lw.length >= 6) 2 else 1)) fix = b.first
        }
        if (fix != null && fix != w) {
            val out = matchCase(w, fix)
            ic.deleteSurroundingText(w.length, 0); ic.commitText(out, 1)
            return Pair(w, out + boundary)
        }
        learnWord(lw)
        return null
    }

    private fun setSug(l: String, c: String, r: String, literalFirst: Boolean = false) {
        sugText[0] = l; sugText[1] = c; sugText[2] = r
        sugViews[0].text = if (literalFirst && l.isNotEmpty()) "“$l”" else l
        sugViews[1].text = c; sugViews[2].text = r
    }

    private fun updateSuggestions() {
        if (listening) return
        val ic = currentInputConnection
        if (!suggestOn || ic == null) { setSug("", "", ""); return }
        val w = wordBefore(ic)
        if (w.isEmpty()) {
            wordMode = false
            val prev = (ic.getTextBeforeCursor(40, 0)?.toString() ?: "").trimEnd().takeLastWhile { it.isLetter() || it == '\'' }.lowercase()
            val n = NEXT[prev] ?: listOf("I", "The", "I'm")
            setSug(n[0], n[1], n[2])
            return
        }
        wordMode = true
        val lw = w.lowercase()
        val comps = dictLower.filter { it.startsWith(lw) && it != lw }.take(3)
        val fix = if (!known(lw)) listOfNotNull(FIXES[lw] ?: best(lw)?.first) else emptyList()
        val list = (fix + comps).distinct().filter { it.lowercase() != lw }
        setSug(w, list.getOrElse(0) { w }, list.getOrElse(1) { "" }, true)
    }

    private fun pick(i: Int) {
        val s = sugText[i]; if (s.isEmpty()) return
        val ic = currentInputConnection ?: return
        val w = wordBefore(ic)
        if (wordMode && i == 0) { learnWord(w.lowercase(), true); ic.commitText(" ", 1) }
        else {
            if (wordMode) ic.deleteSurroundingText(w.length, 0)
            ic.commitText((if (wordMode) matchCase(w, s) else s) + " ", 1)
        }
        undo = null; afterEdit()
    }

    // ---------- emoji ----------
    private fun buildEmoji() {
        emojiPanel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; visibility = View.GONE }
        val tabs = LinearLayout(this).apply { layoutParams = LinearLayout.LayoutParams(-1, dp(40)) }
        EMOJI.forEachIndexed { i, (icon, _) ->
            val tv = TextView(this).apply {
                text = icon; textSize = 20f; gravity = Gravity.CENTER
                layoutParams = LinearLayout.LayoutParams(0, -1, 1f).apply { setMargins(dp(2), dp(2), dp(2), dp(2)) }
                setOnClickListener { showEmoji(i) }
            }
            tabViews.add(tv); tabs.addView(tv)
        }
        tabs.addView(repeatKey("⌫", 1.2f) { backspace() })
        emojiGrid = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        emojiPanel.addView(tabs)
        emojiPanel.addView(ScrollView(this).apply {
            layoutParams = LinearLayout.LayoutParams(-1, 0, 1f); addView(emojiGrid)
        })
        showEmoji(if (recents.isEmpty()) 1 else 0)
    }

    private fun showEmoji(i: Int) {
        tabViews.forEachIndexed { n, tv -> tv.background = if (n == i) glass(70, 10) else null }
        emojiGrid.removeAllViews()
        val list: List<String> = if (i == 0) recents else EMOJI[i].second.split(" ")
        if (list.isEmpty()) { emojiGrid.addView(note("Emojis you use will show up here.")); return }
        for (chunk in list.chunked(8)) {
            val r = LinearLayout(this).apply { layoutParams = LinearLayout.LayoutParams(-1, dp(46)) }
            for (e in chunk) r.addView(TextView(this).apply {
                text = e; textSize = 24f; gravity = Gravity.CENTER
                layoutParams = LinearLayout.LayoutParams(0, -1, 1f)
                setOnClickListener { addEmoji(e) }
            })
            repeat(8 - chunk.size) { r.addView(gap(1f)) }
            emojiGrid.addView(r)
        }
    }

    private fun addEmoji(e: String) {
        currentInputConnection?.commitText(e, 1); undo = null
        recents.remove(e); recents.add(0, e); while (recents.size > 32) recents.removeAt(recents.size - 1)
        prefs.edit().putString("recents", recents.joinToString(" ")).apply()
        updateSuggestions()
    }

    // ---------- clipboard ----------
    private fun buildClip() {
        clipPanel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; visibility = View.GONE }
        val head = LinearLayout(this).apply { layoutParams = LinearLayout.LayoutParams(-1, dp(40)); gravity = Gravity.CENTER_VERTICAL }
        head.addView(TextView(this).apply {
            text = "Clipboard · tap to paste, hold to remove"; setTextColor(0xCCFFFFFF.toInt()); textSize = 13f
            setPadding(dp(10), 0, 0, 0); layoutParams = LinearLayout.LayoutParams(0, -1, 1f); gravity = Gravity.CENTER_VERTICAL
        })
        head.addView(TextView(this).apply {
            text = "Clear"; setTextColor(Color.WHITE); textSize = 14f; gravity = Gravity.CENTER
            background = keyBg(30, 14); setPadding(dp(14), 0, dp(14), 0)
            layoutParams = LinearLayout.LayoutParams(-2, dp(32)).apply { rightMargin = dp(6) }
            setOnClickListener { clips.clear(); saveClips(); refreshClips() }
        })
        clipList = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        clipPanel.addView(head)
        clipPanel.addView(ScrollView(this).apply { layoutParams = LinearLayout.LayoutParams(-1, 0, 1f); addView(clipList) })
    }

    private fun readClip() {
        try {
            val t = cm.primaryClip?.getItemAt(0)?.coerceToText(this)?.toString()?.trim()
            if (!t.isNullOrEmpty() && t != clips.firstOrNull()) {
                clips.remove(t); clips.add(0, t); while (clips.size > 30) clips.removeAt(clips.size - 1)
                saveClips(); if (mode == 2) refreshClips()
            }
        } catch (_: Exception) { }
    }

    private fun saveClips() = prefs.edit().putString("clips", clips.joinToString("\u0001")).apply()

    private fun refreshClips() {
        clipList.removeAllViews()
        if (clips.isEmpty()) { clipList.addView(note("Copy some text and it will show up here.")); return }
        for (c in clips) clipList.addView(TextView(this).apply {
            text = c; maxLines = 2; ellipsize = TextUtils.TruncateAt.END; setTextColor(Color.WHITE); textSize = 15f
            setPadding(dp(14), dp(10), dp(14), dp(10)); background = keyBg(30, 12)
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { setMargins(dp(4), dp(3), dp(4), dp(3)) }
            setOnClickListener { currentInputConnection?.commitText(c, 1); undo = null; afterEdit(); setMode(0) }
            setOnLongClickListener { clips.remove(c); saveClips(); refreshClips(); true }
        })
    }

    // ---------- translate ----------
    private fun buildTranslate() {
        transPanel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; visibility = View.GONE }
        val chips = LinearLayout(this)
        for ((name, code) in LANGS) {
            val tv = TextView(this).apply {
                text = name; setTextColor(Color.WHITE); textSize = 14f; gravity = Gravity.CENTER
                setPadding(dp(14), 0, dp(14), 0)
                layoutParams = LinearLayout.LayoutParams(-2, dp(32)).apply { setMargins(dp(3), dp(4), dp(3), dp(4)) }
                setOnClickListener { selectLang(code) }
            }
            chipViews.add(tv to code); chips.addView(tv)
        }
        transPanel.addView(HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false; layoutParams = LinearLayout.LayoutParams(-1, dp(40)); addView(chips)
        })
        srcView = TextView(this).apply {
            setTextColor(0xAAFFFFFF.toInt()); textSize = 13f; maxLines = 1; ellipsize = TextUtils.TruncateAt.START
            setPadding(dp(10), dp(2), dp(10), dp(2))
        }
        resultView = TextView(this).apply {
            setTextColor(Color.WHITE); textSize = 17f; setPadding(dp(12), dp(8), dp(12), dp(8))
        }
        transPanel.addView(srcView)
        transPanel.addView(ScrollView(this).apply {
            background = glass(26, 12)
            layoutParams = LinearLayout.LayoutParams(-1, 0, 1f).apply { setMargins(dp(4), dp(2), dp(4), dp(2)) }
            addView(resultView)
        })
        val btns = LinearLayout(this).apply { layoutParams = LinearLayout.LayoutParams(-1, dp(46)) }
        btns.addView(key("Translate", 1f, 16f, true) { doTranslate() })
        btns.addView(key("Replace text", 1f, 16f) {
            val ic = currentInputConnection
            if (transResult.isNotEmpty() && ic != null) {
                if (!transSelected) ic.deleteSurroundingText(transSrcLen, 0)
                ic.commitText(transResult, 1); undo = null; setMode(0); afterEdit()
            }
        })
        transPanel.addView(btns)
        selectLang(targetLang)
    }

    private fun selectLang(code: String) {
        targetLang = code
        for ((tv, c) in chipViews) tv.background = if (c == code) accent(0xCC, 16) else glass(30, 16)
    }

    private fun grabSource(): String {
        val ic = currentInputConnection ?: return ""
        val sel = ic.getSelectedText(0)?.toString()
        if (!sel.isNullOrEmpty()) { transSelected = true; transSrcLen = sel.length; return sel }
        transSelected = false
        val t = ic.getTextBeforeCursor(500, 0)?.toString() ?: ""
        transSrcLen = t.length
        return t
    }

    private fun doTranslate() {
        val src = grabSource().trim()
        srcView.text = src.takeLast(80)
        if (src.isEmpty()) { resultView.text = "Type something in the text box first, then tap Translate."; return }
        resultView.text = "Translating…"; transResult = ""
        val lang = targetLang
        thread {
            val out = try {
                val url = URL("https://api.mymemory.translated.net/get?q=" + URLEncoder.encode(src, "UTF-8") + "&langpair=Autodetect%7C" + lang)
                val con = url.openConnection() as HttpURLConnection
                con.connectTimeout = 8000; con.readTimeout = 8000
                val body = con.inputStream.bufferedReader().use { it.readText() }
                val t = JSONObject(body).getJSONObject("responseData").getString("translatedText")
                Html.fromHtml(t, Html.FROM_HTML_MODE_LEGACY).toString()
            } catch (e: Exception) { null }
            ui.post {
                if (out == null) resultView.text = "Couldn't translate. Check your connection and try again."
                else { transResult = out; resultView.text = out }
            }
        }
    }

    // ---------- voice typing ----------
    private fun toggleVoice() {
        if (listening) { stopVoice(); return }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            startActivity(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK).putExtra("ask_mic", true))
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            Toast.makeText(this, "Speech recognition isn't available on this device", Toast.LENGTH_SHORT).show(); return
        }
        toolsOpen = false; showTools()
        val sr = SpeechRecognizer.createSpeechRecognizer(this); speech = sr
        sr.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(p: Bundle?) { setSug("", "🎤 Listening…", "") }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(v: Float) {}
            override fun onBufferReceived(b: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onEvent(t: Int, p: Bundle?) {}
            override fun onPartialResults(p: Bundle?) {
                val t = p?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                if (!t.isNullOrEmpty()) setSug("", "🎤 " + t.takeLast(40), "")
            }
            override fun onResults(r: Bundle?) {
                val t = r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                if (!t.isNullOrEmpty()) {
                    val out = if (shift > 0) t.replaceFirstChar { it.uppercase() } else t
                    currentInputConnection?.commitText("$out ", 1); undo = null
                }
                stopVoice(); afterEdit()
            }
            override fun onError(e: Int) {
                if (e == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS)
                    startActivity(Intent(this@GlassKeyboardService, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK).putExtra("ask_mic", true))
                stopVoice()
            }
        })
        listening = true; micBtn.text = "🔴"
        sr.startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault().toLanguageTag()))
    }

    private fun stopVoice() {
        val was = listening
        listening = false
        speech?.destroy(); speech = null
        if (::micBtn.isInitialized) micBtn.text = "🎤"
        if (was && ::suggestRow.isInitialized) updateSuggestions()
    }
}
