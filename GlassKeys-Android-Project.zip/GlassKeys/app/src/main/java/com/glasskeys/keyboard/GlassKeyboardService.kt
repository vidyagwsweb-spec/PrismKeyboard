package com.glasskeys.keyboard

import android.Manifest
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.StateListDrawable
import android.inputmethodservice.InputMethodService
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.SoundPool
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.text.Html
import android.text.InputType
import android.text.TextUtils
import android.view.*
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputConnection
import android.view.inputmethod.InputMethodManager
import android.widget.*
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.Locale
import kotlin.concurrent.thread

private const val WORDS = "the be to of and a in that have I it for not on with he as you do at this but his by from they we say her she or an will my one all would there their what so up out if about who get which go me when make can like time no just him know take people into year your good some could them see other than then now look only come its over think also back after use two how our work first well way even new want because any these give day most us hello hi hey thanks thank please sorry yes okay ok yeah great awesome love happy tomorrow today tonight morning night later soon meet call text message send phone home friend friends family dinner lunch coffee tired busy free late early sure maybe really very much many more less here where why while been being were was is are am did does done doing going gone coming don't can't it's that's what's let's you're I'm I've won't didn't doesn't isn't wasn't need needs help thing things something nothing everything everyone someone anyone place week weekend month years always never often again still already should must might around before between through during without within find found tell told ask asked feel felt keep kept let begin start started stop try tried talk talked turn turned run ran walk move live lived believe hold bring brought happen happened write wrote provide sit stand lose pay paid meet include continue set learn change lead understand watch follow create speak read allow add spend grow open walk win offer remember consider appear buy wait serve die send expect build stay fall cut reach kill remain suggest raise pass sell require report decide pull school work job money car book game food water music movie phone computer email number name question answer idea problem story woman man child girl boy mother father brother sister party birthday congratulations welcome definitely probably actually because beautiful important different another little right wrong best better worst bad nice fine cool fun funny long short big small old young hot cold hard easy ready sorry"
private val RANKED: List<String> = WORDS.split(" ").map { it.lowercase() }.distinct()
private val RANK: HashMap<String, Int> = HashMap<String, Int>().also { m -> RANKED.forEachIndexed { i, w -> m[w] = i } }

// Only fixes for things that are never a different valid word ("lets", "ill", "were", "well" are left alone).
private val FIXES = mapOf(
    "i" to "I", "im" to "I'm", "i'm" to "I'm", "ive" to "I've", "i've" to "I've", "i'll" to "I'll", "i'd" to "I'd",
    "dont" to "don't", "cant" to "can't", "wont" to "won't", "didnt" to "didn't", "doesnt" to "doesn't",
    "isnt" to "isn't", "wasnt" to "wasn't", "couldnt" to "couldn't", "wouldnt" to "wouldn't",
    "shouldnt" to "shouldn't", "youre" to "you're", "thats" to "that's", "whats" to "what's",
    "theyre" to "they're", "arent" to "aren't", "havent" to "haven't",
    "teh" to "the", "recieve" to "receive", "definately" to "definitely", "thier" to "their",
    "wierd" to "weird", "tommorow" to "tomorrow", "seperate" to "separate", "alot" to "a lot",
    "becuase" to "because", "freind" to "friend", "wich" to "which", "adn" to "and", "hte" to "the"
)
private val NEXT = mapOf(
    "i" to listOf("am", "will", "have"), "i'm" to listOf("not", "going", "so"),
    "thank" to listOf("you", "you so", "goodness"), "thanks" to listOf("for", "so", "a"),
    "how" to listOf("are", "to", "much"), "what" to listOf("is", "are", "do"),
    "see" to listOf("you", "the", "if"), "good" to listOf("morning", "night", "luck"),
    "have" to listOf("a", "to", "been"), "going" to listOf("to", "on", "home"),
    "let" to listOf("me", "us", "you"), "do" to listOf("you", "not", "it"),
    "are" to listOf("you", "we", "they"), "you" to listOf("are", "can", "have"),
    "the" to listOf("best", "same", "first"), "to" to listOf("be", "the", "do"),
    "hello" to listOf("there", "everyone", "!"), "see you" to listOf("soon", "later", "tomorrow"),
    "i'll" to listOf("be", "see", "let"), "can" to listOf("you", "i", "we"),
    "will" to listOf("be", "you", "do"), "would" to listOf("you", "be", "like"),
    "when" to listOf("are", "is", "do"), "where" to listOf("are", "is", "do"),
    "of" to listOf("the", "course", "my"), "in" to listOf("the", "a", "my"),
    "on" to listOf("the", "my", "a"), "for" to listOf("the", "a", "you"),
    "is" to listOf("it", "the", "a"), "it" to listOf("is", "was", "will"),
    "that" to listOf("is", "was", "would"), "this" to listOf("is", "was", "will"),
    "sounds" to listOf("good", "great", "like"), "looking" to listOf("forward", "for", "at"),
    "no" to listOf("problem", "worries", "one"), "talk" to listOf("to", "later", "soon")
)

private class EmojiTab(val icon: Int, val items: String)
private val EMOJI = listOf(
    EmojiTab(R.drawable.ic_recent, ""),
    EmojiTab(R.drawable.ic_emoji, "😀 😃 😄 😁 😆 😅 😂 🤣 😊 😇 🙂 😉 😍 🥰 😘 😋 😛 😜 🤪 🤔 🤨 😐 😏 🙄 😬 😴 😷 🥵 🥶 😎 🤓 😕 🙁 😮 😳 🥺 😢 😭 😱 😤 😡 🤬 😈 💀 🤡 👻 🤖"),
    EmojiTab(R.drawable.ic_cat_heart, "👍 👎 👌 ✌️ 🤞 🤟 🤘 🤙 👈 👉 👆 👇 👋 ✋ 👏 🙌 🙏 🤝 💪 ❤️ 🧡 💛 💚 💙 💜 🖤 🤍 💔 💕 💞 💓 💗 💖 💘 ✨ 🔥 💯 ✅ ❌ ⭐ 🎉"),
    EmojiTab(R.drawable.ic_cat_nature, "🐶 🐱 🐭 🐹 🐰 🦊 🐻 🐼 🐨 🐯 🦁 🐮 🐷 🐸 🐵 🐔 🐧 🐦 🦉 🐺 🐴 🦄 🐝 🦋 🐢 🐍 🐙 🐬 🐳 🌸 🌹 🌻 🌲 🌴 🌵 🍀 🌍 🌙 ☀️ 🌈 ❄️ ⚡ 🌊"),
    EmojiTab(R.drawable.ic_cat_food, "🍎 🍊 🍋 🍌 🍉 🍇 🍓 🍒 🥭 🍍 🥑 🍅 🥕 🌽 🥔 🍞 🧀 🍳 🥓 🍔 🍟 🍕 🌭 🌮 🍝 🍜 🍣 🍱 🍦 🍩 🍪 🎂 🍰 🍫 🍿 ☕ 🍵 🥤 🍺 🍷 🥂 🍹"),
    EmojiTab(R.drawable.ic_cat_activity, "⚽ 🏀 🏈 ⚾ 🎾 🏐 🎱 🏓 🥊 🎯 ⛳ 🎮 🎲 🧩 🎨 🎬 🎤 🎧 🎸 🎹 🥁 📚 ✈️ 🚗 🚕 🚌 🚲 🚀 🚢 🏠 🏖️ ⛺ 🗽 🏰 🎡 🏆 🥇 🎁 🎈 🎊"),
    EmojiTab(R.drawable.ic_cat_objects, "📱 💻 ⌨️ 📷 🔋 💡 📺 ⏰ ⌛ 💰 💳 💎 🔧 🔨 🔑 🔒 📌 📎 ✏️ 📝 📅 📧 📦 🛒 🎒 👑 👓 👟 👗 💄 🧸 🔔 🔍 🚨 ⚠️ ♻️ 💬 💭 🔗 ➡️ 🔄")
)
private val LANGS = listOf(
    "Español" to "es", "Français" to "fr", "Deutsch" to "de", "Italiano" to "it", "Português" to "pt",
    "हिन्दी" to "hi", "العربية" to "ar", "中文" to "zh-CN", "日本語" to "ja", "한국어" to "ko",
    "Русский" to "ru", "Türkçe" to "tr", "English" to "en"
)

// ---------- long-press alternates ----------
private fun al(s: String) = s.split(" ")
private val ALT: HashMap<Char, List<String>> = hashMapOf(
    'a' to al("à á â ä æ ã å ā"), 'c' to al("ç ć č"), 'd' to al("ð ď"), 'e' to al("è é ê ë ē ė ę"),
    'f' to al("ƒ"), 'g' to al("ğ ĝ"), 'h' to al("ħ"), 'i' to al("ì í î ï ī į ı"), 'j' to al("ĵ"),
    'k' to al("ķ"), 'l' to al("ł ļ ľ"), 'm' to al("µ"), 'n' to al("ñ ń ň"),
    'o' to al("ò ó ô ö œ õ ø ō"), 'p' to al("þ ¶"), 'r' to al("ř ŕ ®"), 's' to al("ß ś š ş"),
    't' to al("þ ť ™"), 'u' to al("ù ú û ü ū ů ű"), 'w' to al("ŵ"), 'x' to al("×"),
    'y' to al("ý ÿ ŷ"), 'z' to al("ž ź ż"),
    '1' to al("¹ ½ ⅓ ¼"), '2' to al("² ⅔"), '3' to al("³ ¾"), '4' to al("⁴"), '5' to al("⁵ ‰"),
    '6' to al("⁶"), '7' to al("⁷"), '8' to al("⁸ ∞"), '9' to al("⁹"), '0' to al("⁰ ° ∅ ⁿ"),
    ',' to al("; : ! ? ' \""), '.' to al("… ! ? : ; · •"),
    '@' to al("© ® ™"), '#' to al("№ ♯"), '$' to al("€ £ ¥ ¢ ₹ ₩ ₽"), '%' to al("‰ ℅"), '&' to al("§ ¶"),
    '-' to al("– — • ·"), '+' to al("± × ÷"), '(' to al("[ { <"), ')' to al("] } >"), '/' to al("\\ | ÷"),
    '_' to al("‿ ¯"), '=' to al("≠ ≈ ≡ ≤ ≥"), '*' to al("† ‡ ★ •"), '"' to al("“ ” „ « »"),
    '\'' to al("‘ ’ ‚ ‹ ›"), ':' to al("… ∶"), ';' to al("…"), '!' to al("¡ ‼"), '?' to al("¿ ⁇"),
    '<' to al("≤ « ‹"), '>' to al("≥ » ›"), '[' to al("( {"), ']' to al(") }"), '{' to al("( ["),
    '}' to al(") ]"), '|' to al("¦ ‖"), '~' to al("≈ ∼")
)
private val FALLBACK = listOf("@", "#", "&", "_", "~")

// ---------- spell helpers ----------
private const val EDIT_ALPHA = "abcdefghijklmnopqrstuvwxyz'"
private val KB_ROWS = listOf("qwertyuiop", "asdfghjkl", "zxcvbnm")

private fun adjacentKeys(a: Char, b: Char): Boolean {
    var ra = -1; var ca = -1; var rb = -1; var cb = -1
    for ((r, row) in KB_ROWS.withIndex()) {
        val i = row.indexOf(a); if (i >= 0) { ra = r; ca = i }
        val j = row.indexOf(b); if (j >= 0) { rb = r; cb = j }
    }
    if (ra < 0 || rb < 0) return false
    return Math.abs(ra - rb) <= 1 && Math.abs(ca - cb) <= 1 && !(ra == rb && ca == cb)
}

private fun isSwap(a: String, b: String): Boolean {
    if (a.length != b.length) return false
    val d = a.indices.filter { a[it] != b[it] }
    return d.size == 2 && d[1] == d[0] + 1 && a[d[0]] == b[d[1]] && a[d[1]] == b[d[0]]
}

private fun isAdjSub(a: String, b: String): Boolean {
    if (a.length != b.length) return false
    val d = a.indices.filter { a[it] != b[it] }
    return d.size == 1 && adjacentKeys(a[d[0]], b[d[0]])
}

private fun edits1(w: String): List<String> {
    val out = ArrayList<String>(w.length * 56 + 30)
    for (i in 0..w.length) {
        val l = w.substring(0, i); val r = w.substring(i)
        if (r.isNotEmpty()) out.add(l + r.substring(1))
        if (r.length > 1) out.add(l + r[1] + r[0] + r.substring(2))
        for (c in EDIT_ALPHA) {
            if (r.isNotEmpty()) out.add(l + c + r.substring(1))
            out.add(l + c + r)
        }
    }
    return out
}

private fun lowerBound(a: Array<String>, p: String): Int {
    var lo = 0; var hi = a.size
    while (lo < hi) { val m = (lo + hi) ushr 1; if (a[m] < p) lo = m + 1 else hi = m }
    return lo
}

/** A key that can draw a vector icon instead of text. */
private class KeyView(ctx: Context) : TextView(ctx) {
    private var icon: Drawable? = null
    private var iconPx = 0
    fun setIcon(d: Drawable?, px: Int) { icon = d; iconPx = px; invalidate() }
    override fun onDraw(canvas: Canvas) {
        val d = icon
        if (d == null) { super.onDraw(canvas); return }
        val l = (width - iconPx) / 2; val t = (height - iconPx) / 2
        d.setBounds(l, t, l + iconPx, t + iconPx); d.draw(canvas)
    }
}

class GlassKeyboardService : InputMethodService() {
    private val ui = Handler(Looper.getMainLooper())
    private val learned = HashSet<String>()
    private val seen = HashMap<String, Int>()
    private val userFreq = HashMap<String, Int>()
    private val bigram = HashMap<String, HashMap<String, Int>>()
    private var dirty = 0
    private val clips = ArrayList<String>()
    private val recents = ArrayList<String>()
    private lateinit var prefs: SharedPreferences
    private lateinit var cm: ClipboardManager
    private lateinit var audio: AudioManager
    private val clipListener = ClipboardManager.OnPrimaryClipChangedListener { readClip() }

    // big dictionary, loaded in the background
    @Volatile private var valid: HashSet<String>? = null
    @Volatile private var properSet: HashSet<String>? = null
    @Volatile private var common: Array<String>? = null

    // blur
    private var blurOk = false
    private val blurListener = java.util.function.Consumer<Boolean> { on -> blurOk = on; applyGlassBackground() }

    // sound
    private var sound: SoundPool? = null
    private var tickA = 0
    private var tickB = 0
    private var soundOn = true

    private lateinit var rootView: LinearLayout
    private lateinit var keysPanel: LinearLayout
    private lateinit var emojiPanel: LinearLayout
    private lateinit var emojiGrid: LinearLayout
    private lateinit var clipPanel: LinearLayout
    private lateinit var clipList: LinearLayout
    private lateinit var transPanel: LinearLayout
    private lateinit var suggestRow: LinearLayout
    private lateinit var toolRow: LinearLayout
    private lateinit var toggleBtn: KeyView
    private lateinit var symKey: KeyView
    private lateinit var enterKey: KeyView
    private lateinit var micBtn: KeyView
    private lateinit var soundBtn: KeyView
    private lateinit var srcView: TextView
    private lateinit var resultView: TextView
    private val sugViews = ArrayList<TextView>()
    private val sugText = arrayOf("", "", "")
    private val tabViews = ArrayList<KeyView>()
    private val chipViews = ArrayList<Pair<TextView, String>>()

    private var mode = 0 // 0 keys, 1 emoji, 2 clipboard, 3 translate
    private var shift = 0 // 0 off, 1 once, 2 caps lock
    private var lastShiftTap = 0L
    private var symbols = false
    private var suggestOn = true
    private var wordMode = false
    private var literal0 = false
    private var undo: Pair<String, String>? = null
    private var toolsOpen = false
    private var speech: SpeechRecognizer? = null
    private var listening = false
    private var targetLang = "es"
    private var transSrcLen = 0
    private var transSelected = false
    private var transResult = ""

    // long-press popup
    private var popup: PopupWindow? = null
    private var popVals: List<String> = emptyList()
    private val popViews = ArrayList<TextView>()
    private var popLeft = 0
    private var popItemW = 1
    private var popPad = 0
    private var popKeyBottom = 0
    private var popSel = 0

    // ---------- lifecycle ----------
    override fun onCreate() {
        super.onCreate()
        prefs = getSharedPreferences("glass", MODE_PRIVATE)
        learned.addAll(prefs.getStringSet("learned", emptySet()) ?: emptySet())
        prefs.getString("clips", "")?.split("\u0001")?.filter { it.isNotBlank() }?.let { clips.addAll(it) }
        prefs.getString("recents", "")?.split(" ")?.filter { it.isNotBlank() }?.let { recents.addAll(it) }
        prefs.getString("uf", "")?.lineSequence()?.forEach {
            val p = it.split("\t")
            if (p.size == 2) p[1].toIntOrNull()?.let { n -> userFreq[p[0]] = n }
        }
        prefs.getString("bg", "")?.lineSequence()?.forEach {
            val p = it.split("\t")
            if (p.size == 3) p[2].toIntOrNull()?.let { n -> bigram.getOrPut(p[0]) { HashMap() }[p[1]] = n }
        }
        soundOn = prefs.getBoolean("sound", true)
        cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
        cm.addPrimaryClipChangedListener(clipListener)
        audio = getSystemService(AUDIO_SERVICE) as AudioManager
        initSound()
        loadDict()
        if (Build.VERSION.SDK_INT >= 31) {
            (getSystemService(WINDOW_SERVICE) as WindowManager).addCrossWindowBlurEnabledListener(mainExecutor, blurListener)
        }
    }

    override fun onDestroy() {
        if (Build.VERSION.SDK_INT >= 31) {
            (getSystemService(WINDOW_SERVICE) as WindowManager).removeCrossWindowBlurEnabledListener(blurListener)
        }
        cm.removePrimaryClipChangedListener(clipListener)
        saveLearning()
        dismissPopup()
        sound?.release(); sound = null
        stopVoice()
        super.onDestroy()
    }

    override fun onEvaluateFullscreenMode() = false

    override fun onWindowShown() {
        super.onWindowShown()
        applyGlassBackground()
    }

    override fun onStartInputView(info: EditorInfo, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        if (!::keysPanel.isInitialized) return
        val t = info.inputType
        val cls = t and InputType.TYPE_MASK_CLASS
        val v = t and InputType.TYPE_MASK_VARIATION
        val blocked = listOf(
            InputType.TYPE_TEXT_VARIATION_PASSWORD, InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD,
            InputType.TYPE_TEXT_VARIATION_WEB_PASSWORD, InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS,
            InputType.TYPE_TEXT_VARIATION_WEB_EMAIL_ADDRESS, InputType.TYPE_TEXT_VARIATION_URI)
        suggestOn = cls == InputType.TYPE_CLASS_TEXT && (t and InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS) == 0 && v !in blocked
        symbols = cls == InputType.TYPE_CLASS_NUMBER || cls == InputType.TYPE_CLASS_PHONE
        enterKey.ic(when (info.imeOptions and EditorInfo.IME_MASK_ACTION) {
            EditorInfo.IME_ACTION_SEARCH -> R.drawable.ic_search
            EditorInfo.IME_ACTION_SEND -> R.drawable.ic_send
            EditorInfo.IME_ACTION_GO, EditorInfo.IME_ACTION_NEXT, EditorInfo.IME_ACTION_DONE -> R.drawable.ic_check
            else -> R.drawable.ic_enter
        })
        undo = null
        readClip()
        setMode(0)
        afterEdit(true)
    }

    override fun onFinishInputView(finishing: Boolean) {
        dismissPopup()
        saveLearning()
        stopVoice()
        super.onFinishInputView(finishing)
    }

    // ---------- dictionary ----------
    private fun loadDict() {
        thread {
            try {
                val all = HashSet<String>(170_000)
                val prop = HashSet<String>(20_000)
                val cmn = ArrayList<String>(120_000)
                resources.openRawResource(R.raw.words).bufferedReader().useLines { seq ->
                    for (ln in seq) {
                        if (ln.isEmpty()) continue
                        if (ln[0] == '^') { val p = ln.substring(1); all.add(p); prop.add(p) }
                        else { all.add(ln); cmn.add(ln) }
                    }
                }
                cmn.sort()
                properSet = prop; common = cmn.toTypedArray(); valid = all
                ui.post { if (::keysPanel.isInitialized) updateSuggestions() }
            } catch (_: Exception) { }
        }
    }

    // ---------- sound ----------
    private fun wavBytes(freq: Double, ms: Int, vol: Double): ByteArray {
        val sr = 22050
        val n = sr * ms / 1000
        val pcm = ByteArray(n * 2)
        var seed = 12345
        for (i in 0 until n) {
            val t = i.toDouble() / sr
            val env = Math.exp(-t * 300.0)
            seed = seed * 1103515245 + 12345
            val noise = ((seed shr 16) and 0x7fff) / 16384.0 - 1.0
            val s = (Math.sin(2 * Math.PI * freq * t) * 0.85 + noise * 0.3) * env * vol
            val v = (s.coerceIn(-1.0, 1.0) * 32767).toInt()
            pcm[2 * i] = (v and 0xff).toByte(); pcm[2 * i + 1] = ((v shr 8) and 0xff).toByte()
        }
        val bb = ByteBuffer.allocate(44 + pcm.size).order(ByteOrder.LITTLE_ENDIAN)
        bb.put("RIFF".toByteArray()); bb.putInt(36 + pcm.size); bb.put("WAVE".toByteArray())
        bb.put("fmt ".toByteArray()); bb.putInt(16); bb.putShort(1); bb.putShort(1)
        bb.putInt(sr); bb.putInt(sr * 2); bb.putShort(2); bb.putShort(16)
        bb.put("data".toByteArray()); bb.putInt(pcm.size); bb.put(pcm)
        return bb.array()
    }

    private fun initSound() {
        try {
            val attrs = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build()
            val pool = SoundPool.Builder().setMaxStreams(4).setAudioAttributes(attrs).build()
            val a = File(cacheDir, "tick_a.wav").apply { writeBytes(wavBytes(2200.0, 16, 0.9)) }
            val b = File(cacheDir, "tick_b.wav").apply { writeBytes(wavBytes(1300.0, 18, 0.9)) }
            tickA = pool.load(a.absolutePath, 1)
            tickB = pool.load(b.absolutePath, 1)
            sound = pool
        } catch (_: Exception) { sound = null }
    }

    /** kind 0 = letters/symbols, 1 = space, delete, enter and other function keys */
    private fun tick(kind: Int = 0) {
        if (!soundOn) return
        val p = sound ?: return
        if (audio.ringerMode != AudioManager.RINGER_MODE_NORMAL) return
        p.play(if (kind == 0) tickA else tickB, 1f, 1f, 1, 0, 1f)
    }

    // ---------- glass styling ----------
    private fun dp(v: Int) = (v * resources.displayMetrics.density + 0.5f).toInt()

    private fun KeyView.ic(res: Int, dpSize: Int = 22) { setIcon(getDrawable(res)?.mutate(), dp(dpSize)) }

    private fun glass(a: Int, r: Int): GradientDrawable =
        GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
            intArrayOf(Color.argb(minOf(a + 28, 255), 255, 255, 255), Color.argb(a, 255, 255, 255))).apply {
            cornerRadius = dp(r).toFloat(); setStroke(dp(1), Color.argb(70, 255, 255, 255))
        }

    private fun keyBg(a: Int = 38, r: Int = 12): Drawable = StateListDrawable().apply {
        addState(intArrayOf(android.R.attr.state_pressed), glass(130, r))
        addState(intArrayOf(), glass(a, r))
    }

    private fun accent(alpha: Int = 0xCC, r: Int = 12): Drawable {
        fun g(c1: Long, c2: Long) = GradientDrawable(GradientDrawable.Orientation.TL_BR,
            intArrayOf(c1.toInt(), c2.toInt())).apply { cornerRadius = dp(r).toFloat(); setStroke(dp(1), 0x88FFFFFF.toInt()) }
        return StateListDrawable().apply {
            addState(intArrayOf(android.R.attr.state_pressed), g(0xFFA9C8FF, 0xFFD2B0FF))
            addState(intArrayOf(), g(0x00000000L or (alpha.toLong() shl 24) or 0x6FA3FF, 0x00000000L or (alpha.toLong() shl 24) or 0xA878FF))
        }
    }

    /** Tint laid over the blurred backdrop. Without window blur it is much more opaque so keys stay readable. */
    private fun rootBg(): Drawable {
        val a = if (blurOk) 0x8C else 0xEA
        return GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
            intArrayOf(Color.argb(a, 24, 34, 70), Color.argb(a, 50, 28, 88)))
    }

    /** Blurs whatever is behind the keyboard window (Android 12+ when the device allows window blur). */
    private fun applyGlassBackground() {
        val win = window?.window ?: return
        win.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        if (Build.VERSION.SDK_INT >= 31) {
            val on = (getSystemService(WINDOW_SERVICE) as WindowManager).isCrossWindowBlurEnabled
            blurOk = on
            win.setBackgroundBlurRadius(if (on) dp(30) else 0)
        } else blurOk = false
        if (::rootView.isInitialized) rootView.background = rootBg()
    }

    private fun popupBg() = GradientDrawable().apply {
        setColor(0xF0242A52.toInt()); cornerRadius = dp(14).toFloat(); setStroke(dp(1), 0x66FFFFFF)
    }

    private fun key(label: String = "", w: Float = 1f, size: Float = 20f, acc: Boolean = false, icon: Int = 0,
                    tickKind: Int = 0, alts: (() -> List<String>)? = null, onLong: (() -> Unit)? = null,
                    onClick: (View) -> Unit): KeyView {
        val k = KeyView(this)
        var popupOpen = false
        var consumed = false
        var cancelled = false
        val longRun = Runnable {
            if (!k.isPressed || cancelled) return@Runnable
            val list = alts?.invoke().orEmpty()
            if (list.isNotEmpty()) {
                popupOpen = true
                k.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
                showPopup(k, list)
            } else if (onLong != null) {
                consumed = true
                k.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
                onLong()
            }
        }
        k.apply {
            text = label; gravity = Gravity.CENTER; setTextColor(Color.WHITE); textSize = size
            if (icon != 0) ic(icon)
            background = if (acc) accent() else keyBg()
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, w).apply {
                setMargins(dp(2), dp(3), dp(2), dp(3))
            }
            isClickable = true
        }
        k.setOnTouchListener { v, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    popupOpen = false; consumed = false; cancelled = false
                    v.isPressed = true
                    v.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
                    tick(tickKind)
                    if (alts != null || onLong != null) ui.postDelayed(longRun, 330)
                }
                MotionEvent.ACTION_MOVE -> {
                    if (popupOpen) updatePopup(e.rawX, e.rawY)
                    else if (!cancelled) {
                        val m = dp(10)
                        if (e.x < -m || e.x > v.width + m || e.y < -m || e.y > v.height + m) {
                            cancelled = true; v.isPressed = false; ui.removeCallbacks(longRun)
                        }
                    }
                }
                MotionEvent.ACTION_UP -> {
                    ui.removeCallbacks(longRun); v.isPressed = false
                    if (popupOpen) {
                        val s = popupChoice(); dismissPopup(); popupOpen = false
                        if (s != null) type(s)
                    } else if (!consumed && !cancelled) onClick(v)
                }
                MotionEvent.ACTION_CANCEL -> {
                    ui.removeCallbacks(longRun); v.isPressed = false
                    dismissPopup(); popupOpen = false
                }
            }
            true
        }
        return k
    }

    private fun repeatKey(icon: Int, w: Float, act: () -> Unit): KeyView {
        val k = key("", w, icon = icon, tickKind = 1) { }
        val rep = object : Runnable { override fun run() { act(); ui.postDelayed(this, 50) } }
        k.setOnTouchListener { v, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    v.isPressed = true; v.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
                    tick(1); act(); ui.postDelayed(rep, 400)
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> { v.isPressed = false; ui.removeCallbacks(rep) }
            }
            true
        }
        return k
    }

    // ---------- long-press popup ----------
    private fun altsFor(ch: Char): List<String> {
        val base = ALT[ch.lowercaseChar()] ?: if (ch.isLetter()) FALLBACK else emptyList()
        val list = if (shift > 0 && ch.isLetter()) base.map { it.uppercase() } else base
        return list.take(9)
    }

    private fun showPopup(anchor: View, vals: List<String>) {
        dismissPopup()
        if (vals.isEmpty()) return
        val screenW = resources.displayMetrics.widthPixels
        val itemW = minOf(dp(42), (screenW - dp(24)) / vals.size)
        val itemH = dp(50); val pad = dp(5)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; setPadding(pad, pad, pad, pad); background = popupBg()
        }
        popViews.clear()
        for (s in vals) {
            val tv = TextView(this).apply {
                text = s; textSize = 22f; gravity = Gravity.CENTER; setTextColor(Color.WHITE)
                layoutParams = LinearLayout.LayoutParams(itemW, itemH)
            }
            popViews.add(tv); box.addView(tv)
        }
        val w = itemW * vals.size + pad * 2
        val h = itemH + pad * 2
        val loc = IntArray(2); anchor.getLocationOnScreen(loc)
        var x = loc[0] + anchor.width / 2 - w / 2
        x = x.coerceIn(dp(4), maxOf(dp(4), screenW - w - dp(4)))
        val y = loc[1] - h - dp(6)
        popVals = vals; popLeft = x; popItemW = itemW; popPad = pad; popKeyBottom = loc[1] + anchor.height; popSel = 0
        val pw = PopupWindow(box, w, h, false)
        pw.isClippingEnabled = false
        pw.isTouchable = false
        pw.elevation = dp(8).toFloat()
        try { pw.showAtLocation(rootView, Gravity.NO_GRAVITY, x, y) } catch (_: Exception) { popVals = emptyList(); return }
        popup = pw
        highlightPopup(0)
    }

    private fun highlightPopup(i: Int) {
        popSel = i
        popViews.forEachIndexed { n, tv -> tv.background = if (n == i) accent(0xFF, 10) else null }
    }

    private fun updatePopup(rx: Float, ry: Float) {
        if (popVals.isEmpty()) return
        if (ry > popKeyBottom + dp(30)) { highlightPopup(-1); return }
        val idx = ((rx - popLeft - popPad) / popItemW).toInt().coerceIn(0, popVals.size - 1)
        if (idx != popSel) highlightPopup(idx)
    }

    private fun popupChoice(): String? = popVals.getOrNull(popSel)

    private fun dismissPopup() {
        try { popup?.dismiss() } catch (_: Exception) { }
        popup = null; popVals = emptyList(); popViews.clear()
    }

    private fun row() = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        layoutParams = LinearLayout.LayoutParams(-1, 0, 1f)
    }

    private fun gap(w: Float) = Space(this).apply { layoutParams = LinearLayout.LayoutParams(0, -1, w) }

    private fun note(t: String) = TextView(this).apply {
        text = t; setTextColor(0xAAFFFFFF.toInt()); textSize = 14f; gravity = Gravity.CENTER
        setPadding(dp(12), dp(24), dp(12), dp(24))
    }

    // ---------- view tree ----------
    override fun onCreateInputView(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; background = rootBg()
            setPadding(dp(4), dp(6), dp(4), dp(8))
        }
        rootView = root
        sugViews.clear(); tabViews.clear(); chipViews.clear()
        // strip: toggle + suggestions / tools
        val strip = LinearLayout(this).apply { layoutParams = LinearLayout.LayoutParams(-1, dp(42)) }
        toggleBtn = KeyView(this).apply {
            ic(R.drawable.ic_chevron, 20)
            layoutParams = LinearLayout.LayoutParams(dp(40), -1)
            setOnClickListener { tick(1); toolsOpen = !toolsOpen; showTools() }
        }
        val frame = FrameLayout(this).apply { layoutParams = LinearLayout.LayoutParams(0, -1, 1f) }
        suggestRow = LinearLayout(this)
        for (i in 0..2) {
            val tv = TextView(this).apply {
                gravity = Gravity.CENTER; setTextColor(Color.WHITE); textSize = 16f
                maxLines = 1; ellipsize = TextUtils.TruncateAt.END
                layoutParams = LinearLayout.LayoutParams(0, -1, 1f)
                setOnClickListener { tick(0); pick(i) }
            }
            if (i == 1) tv.setTypeface(tv.typeface, android.graphics.Typeface.BOLD)
            sugViews.add(tv); suggestRow.addView(tv)
        }
        toolRow = LinearLayout(this).apply { visibility = View.GONE }
        fun tool(res: Int, act: () -> Unit) = KeyView(this).apply {
            ic(res, 24)
            layoutParams = LinearLayout.LayoutParams(0, -1, 1f)
            setOnClickListener { tick(1); act() }
        }
        micBtn = tool(R.drawable.ic_mic) { toggleVoice() }
        soundBtn = tool(if (soundOn) R.drawable.ic_volume_on else R.drawable.ic_volume_off) {
            soundOn = !soundOn
            prefs.edit().putBoolean("sound", soundOn).apply()
            soundBtn.ic(if (soundOn) R.drawable.ic_volume_on else R.drawable.ic_volume_off, 24)
        }
        toolRow.addView(tool(R.drawable.ic_emoji) { toggleMode(1) })
        toolRow.addView(tool(R.drawable.ic_clipboard) { toggleMode(2) })
        toolRow.addView(tool(R.drawable.ic_globe) { toggleMode(3) })
        toolRow.addView(micBtn)
        toolRow.addView(soundBtn)
        frame.addView(suggestRow, FrameLayout.LayoutParams(-1, -1))
        frame.addView(toolRow, FrameLayout.LayoutParams(-1, -1))
        strip.addView(toggleBtn); strip.addView(frame)
        root.addView(strip)

        // panels
        val panel = FrameLayout(this).apply { layoutParams = LinearLayout.LayoutParams(-1, dp(188)) }
        keysPanel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        buildEmoji(); buildClip(); buildTranslate()
        for (p in listOf(keysPanel, emojiPanel, clipPanel, transPanel)) panel.addView(p, FrameLayout.LayoutParams(-1, -1))
        root.addView(panel)

        // bottom row
        val bottom = LinearLayout(this).apply { layoutParams = LinearLayout.LayoutParams(-1, dp(48)) }
        symKey = key("?123", 1.4f, 15f) {
            if (mode != 0) { symbols = true; setMode(0) } else { symbols = !symbols; renderKeys(); symKey.text = if (symbols) "ABC" else "?123" }
        }
        enterKey = key("", 1.4f, 20f, true, icon = R.drawable.ic_enter, tickKind = 1, onLong = {
            currentInputConnection?.let { autoCorrect(it, "") }
            sendDownUpKeyEvents(KeyEvent.KEYCODE_ENTER); undo = null; afterEdit()
        }) { enter() }
        bottom.addView(symKey)
        bottom.addView(key(",", 1f, alts = { altsFor(',') }) { type(",") })
        bottom.addView(key("", 1f, 19f, icon = R.drawable.ic_emoji, tickKind = 1, onLong = { toggleMode(2) }) { toggleMode(1) })
        bottom.addView(key("Glass Keys", 4f, 12f, tickKind = 1, onLong = {
            (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker()
        }) { space() }.also { it.setTextColor(0xAAFFFFFF.toInt()) })
        bottom.addView(key(".", 1f, alts = { altsFor('.') }) { type(".") })
        bottom.addView(enterKey)
        root.addView(bottom)

        renderKeys(); setMode(0); setSug("", "", "")
        applyGlassBackground()
        return root
    }

    private fun renderKeys() {
        keysPanel.removeAllViews()
        val up = shift > 0
        fun letter(c: Char): KeyView {
            val s = if (up) c.uppercaseChar().toString() else c.toString()
            return key(s, alts = { altsFor(c) }) { type(s) }
        }
        val r1 = row(); for (c in "1234567890") r1.addView(key(c.toString(), 1f, 18f, alts = { altsFor(c) }) { type(c.toString()) })
        val a = if (symbols) "@#\$%&-+()/" else "qwertyuiop"
        val b = if (symbols) "_=*\"':;!?" else "asdfghjkl"
        val c3 = if (symbols) "<>[]{}|" else "zxcvbnm"
        val r2 = row(); for (c in a) r2.addView(letter(c))
        val r3 = row(); r3.addView(gap(if (symbols) 0.25f else 0.5f)); for (c in b) r3.addView(letter(c)); r3.addView(gap(if (symbols) 0.25f else 0.5f))
        val r4 = row()
        if (symbols) r4.addView(key("~", 1.5f, alts = { altsFor('~') }) { type("~") })
        else r4.addView(key("", 1.5f, 20f, shift > 0, icon = when (shift) {
            2 -> R.drawable.ic_shift_lock
            1 -> R.drawable.ic_shift_on
            else -> R.drawable.ic_shift
        }, tickKind = 1, onLong = { shift = 2; renderKeys() }) { onShift() })
        for (c in c3) r4.addView(letter(c))
        r4.addView(repeatKey(R.drawable.ic_backspace, 1.5f) { backspace() })
        for (r in listOf(r1, r2, r3, r4)) keysPanel.addView(r)
    }

    private fun onShift() {
        val now = System.currentTimeMillis()
        shift = if (now - lastShiftTap < 350) 2 else if (shift == 0) 1 else 0
        lastShiftTap = now
        renderKeys()
    }

    private fun showTools() {
        toolRow.visibility = if (toolsOpen) View.VISIBLE else View.GONE
        suggestRow.visibility = if (toolsOpen) View.GONE else View.VISIBLE
        toggleBtn.ic(if (toolsOpen) R.drawable.ic_close else R.drawable.ic_chevron, 20)
    }

    private fun toggleMode(m: Int) = setMode(if (mode == m) 0 else m)

    private fun setMode(m: Int) {
        mode = m
        dismissPopup()
        keysPanel.visibility = if (m == 0) View.VISIBLE else View.GONE
        emojiPanel.visibility = if (m == 1) View.VISIBLE else View.GONE
        clipPanel.visibility = if (m == 2) View.VISIBLE else View.GONE
        transPanel.visibility = if (m == 3) View.VISIBLE else View.GONE
        if (m == 0) renderKeys()
        if (m == 2) refreshClips()
        if (m == 3) { srcView.text = grabSource().let { if (it.isBlank()) "Nothing to translate yet" else it.takeLast(80) }; resultView.text = ""; transResult = "" }
        symKey.text = if (m == 0 && symbols) "ABC" else "?123"
    }

    // ---------- typing ----------
    private fun isBoundary(s: String) = s.length == 1 && !s[0].isLetterOrDigit() && s[0] != '\''

    private fun type(s: String) {
        val ic = currentInputConnection ?: return
        val pending = if (isBoundary(s)) autoCorrect(ic, s) else null
        ic.commitText(s, 1)
        undo = pending
        afterEdit()
    }

    private fun space() {
        val ic = currentInputConnection ?: return
        val t = ic.getTextBeforeCursor(2, 0)?.toString() ?: ""
        if (suggestOn && t.length == 2 && t[1] == ' ' && t[0].isLetterOrDigit()) {
            ic.deleteSurroundingText(1, 0); ic.commitText(". ", 1); undo = null; afterEdit(); return
        }
        type(" ")
    }

    private fun backspace() {
        val u = undo
        if (u != null) {
            val ic = currentInputConnection ?: return
            ic.deleteSurroundingText(u.second.length, 0); ic.commitText(u.first, 1)
            learnWord(u.first.lowercase(), true); undo = null; afterEdit(); return
        }
        sendDownUpKeyEvents(KeyEvent.KEYCODE_DEL)
        afterEdit()
    }

    private fun enter() {
        val ic = currentInputConnection ?: return
        autoCorrect(ic, "")
        undo = null
        val ei = currentInputEditorInfo
        val action = ei.imeOptions and EditorInfo.IME_MASK_ACTION
        if ((ei.imeOptions and EditorInfo.IME_FLAG_NO_ENTER_ACTION) == 0 &&
            action != EditorInfo.IME_ACTION_NONE && action != EditorInfo.IME_ACTION_UNSPECIFIED)
            ic.performEditorAction(action)
        else sendDownUpKeyEvents(KeyEvent.KEYCODE_ENTER)
        afterEdit()
    }

    private fun afterEdit(force: Boolean = false) {
        val ic = currentInputConnection
        val ei = currentInputEditorInfo
        if (ic != null && ei != null && shift != 2 && !symbols && ei.inputType != 0) {
            val want = if (ic.getCursorCapsMode(ei.inputType) != 0) 1 else 0
            if (want != shift || force) { shift = want; if (mode == 0) renderKeys() }
        }
        updateSuggestions()
    }

    // ---------- learning ----------
    private fun known(lw: String) = lw in RANK || lw in learned || (userFreq[lw] ?: 0) >= 2 || valid?.contains(lw) == true

    private fun isCommonWord(c: String): Boolean {
        if (c in RANK || (userFreq[c] ?: 0) >= 1) return true
        val v = valid ?: return false
        return v.contains(c) && properSet?.contains(c) != true
    }

    private fun learnWord(lw: String, force: Boolean = false) {
        if (lw.length < 2 || known(lw)) return
        val n = (seen[lw] ?: 0) + 1; seen[lw] = n
        if (force || n >= 2) { learned.add(lw); prefs.edit().putStringSet("learned", HashSet(learned)).apply() }
    }

    /** The word before the text [s] ends with, "" at the start of a sentence, "~" if unclear (comma etc.). */
    private fun prevWord(s: String): String {
        val t = s.trimEnd(' ')
        if (t.isEmpty()) return ""
        val last = t.last()
        if (last == '.' || last == '!' || last == '?' || last == '\n') return ""
        val w = t.takeLastWhile { it.isLetter() || it == '\'' }.lowercase()
        return if (w.isEmpty()) "~" else w
    }

    private fun record(prevText: String, word: String) {
        val lw = word.lowercase()
        if (lw.length < 2 && lw != "i" && lw != "a") return
        if (lw.any { it.isDigit() }) return
        userFreq[lw] = (userFreq[lw] ?: 0) + 1
        val prev = prevWord(prevText)
        if (prev != "~") {
            val m = bigram.getOrPut(prev) { HashMap() }
            m[lw] = (m[lw] ?: 0) + 1
        }
        if (++dirty >= 25) saveLearning()
    }

    private fun saveLearning() {
        if (!::prefs.isInitialized || dirty == 0) return
        dirty = 0
        val uf = userFreq.entries.sortedByDescending { it.value }.take(2000).joinToString("\n") { it.key + "\t" + it.value }
        val flat = ArrayList<Triple<String, String, Int>>()
        for ((p, m) in bigram) for ((c, k) in m) flat.add(Triple(p, c, k))
        flat.sortByDescending { it.third }
        val bg = StringBuilder()
        for (t in flat.take(4000)) bg.append(t.first).append('\t').append(t.second).append('\t').append(t.third).append('\n')
        prefs.edit().putString("uf", uf).putString("bg", bg.toString()).apply()
    }

    // ---------- autocorrect + suggestions ----------
    private fun matchCase(w: String, fix: String): String = when {
        w.isEmpty() || fix.isEmpty() -> fix
        fix[0].isUpperCase() -> fix
        w.length > 1 && w.all { it.isUpperCase() } -> fix.uppercase()
        w[0].isUpperCase() -> fix.replaceFirstChar { it.uppercase() }
        else -> fix
    }

    private fun finalCase(w: String, s: String): String {
        val r = matchCase(w, s)
        return if (r == "i") "I" else if (r.startsWith("i'")) "I" + r.substring(1) else r
    }

    private fun show(s: String, cap: Boolean): String {
        val r = if (cap) s.replaceFirstChar { it.uppercase() } else s
        return if (r == "i") "I" else if (r.startsWith("i'")) "I" + r.substring(1) else r
    }

    private fun dist(a: String, b: String): Int {
        val d = Array(a.length + 1) { IntArray(b.length + 1) }
        for (i in 0..a.length) d[i][0] = i
        for (j in 0..b.length) d[0][j] = j
        for (i in 1..a.length) for (j in 1..b.length) {
            val c = if (a[i - 1] == b[j - 1]) 0 else 1
            d[i][j] = minOf(d[i - 1][j] + 1, d[i][j - 1] + 1, d[i - 1][j - 1] + c)
            if (i > 1 && j > 1 && a[i - 1] == b[j - 2] && a[i - 2] == b[j - 1]) d[i][j] = minOf(d[i][j], d[i - 2][j - 2] + 1)
        }
        return d[a.length][b.length]
    }

    private fun candScore(c: String): Double {
        var s = 0.0
        RANK[c]?.let { s += 200.0 - it * 0.25 }
        userFreq[c]?.let { s += 30.0 + minOf(it, 30) * 3.0 }
        return if (s == 0.0) 1.0 else s
    }

    /** Words one edit away from [lw], best first. Dictionary-only words rank far below common/learned ones. */
    private fun corrections(lw: String, n: Int): List<String> {
        if (lw.length < 2 || lw.any { it.code > 127 }) return emptyList()
        val sc = HashMap<String, Double>()
        for (c in edits1(lw)) if (c != lw && c.length >= 2 && isCommonWord(c)) sc[c] = candScore(c)
        val out = ArrayList(sc.entries.sortedByDescending { it.value }.map { it.key })
        if (out.size < n && lw.length >= 3) {
            for (c in RANKED) {
                if (out.size >= n) break
                if (c !in sc && c[0] == lw[0] && Math.abs(c.length - lw.length) <= 2 && dist(lw, c) <= 2) out.add(c)
            }
        }
        return out.take(n)
    }

    /** Prefix completions: the user's own words and bigrams first, then common words, then shortest dictionary words. */
    private fun completions(lw: String, prev: String, limit: Int): List<String> {
        val sc = HashMap<String, Double>()
        for (i in RANKED.indices) {
            val c = RANKED[i]
            if (c.length > lw.length && c.startsWith(lw)) sc[c] = 200.0 - i * 0.25
        }
        for ((c, n) in userFreq) if (c.length > lw.length && c.startsWith(lw)) sc[c] = maxOf(sc[c] ?: 0.0, 120.0 + minOf(n, 40) * 4.0)
        bigram[prev]?.let { m ->
            for ((c, n) in m) if (c.length > lw.length && c.startsWith(lw)) sc[c] = (sc[c] ?: 0.0) + 150.0 + minOf(n, 30) * 5.0
        }
        val cm = common
        if (sc.size < limit && cm != null) {
            var i = lowerBound(cm, lw); var scanned = 0
            val extra = ArrayList<String>()
            while (i < cm.size && scanned < 3000 && cm[i].startsWith(lw)) {
                val c = cm[i]; if (c.length > lw.length && c !in sc) extra.add(c)
                i++; scanned++
            }
            extra.sortBy { it.length }
            for (c in extra.take(limit)) sc[c] = 10.0 - c.length * 0.1
        }
        return sc.entries.sortedByDescending { it.value }.take(limit).map { it.key }
    }

    /**
     * Returns a replacement only when it is clearly safe: the typed word is not a known word, and exactly one edit
     * away there is a common (or learned) word that is clearly the best match. Names, caps, accents, digits,
     * handles and words typed in the middle of existing text are never touched.
     */
    private fun autoFix(w: String, lw: String): String? {
        FIXES[lw]?.let { return it }
        if (lw.length < 3 || known(lw)) return null
        if (valid == null) return null
        if (w.any { it.code > 127 || it.isDigit() }) return null
        if (w.first() == '\'' || w.last() == '\'') return null
        if (w[0].isUpperCase() || w.drop(1).any { it.isUpperCase() }) return null
        val cands = HashMap<String, Double>()
        for (c in edits1(lw)) if (c != lw && c.length >= 2 && isCommonWord(c)) cands[c] = candScore(c)
        val pool = if (lw.length == 3) cands.filter { isSwap(lw, it.key) || isAdjSub(lw, it.key) } else cands
        if (pool.isEmpty()) return null
        val sorted = pool.entries.sortedByDescending { it.value }
        val top = sorted[0]
        val second = sorted.getOrNull(1)?.value ?: 0.0
        if (top.value >= 40 && top.value >= second * 1.5) return top.key
        if (sorted.size == 1 && lw.length >= 4 && isSwap(lw, top.key)) return top.key
        return null
    }

    private fun autoCorrect(ic: InputConnection, boundary: String): Pair<String, String>? {
        if (!suggestOn) return null
        val before = ic.getTextBeforeCursor(60, 0)?.toString() ?: ""
        val w = before.takeLastWhile { it.isLetter() || it == '\'' }
        if (w.isEmpty()) return null
        val lw = w.lowercase()
        val prevText = before.dropLast(w.length)
        val after = ic.getTextAfterCursor(1, 0)?.toString() ?: ""
        val inMiddle = after.isNotEmpty() && (after[0].isLetterOrDigit() || after[0] == '\'')
        val glued = prevText.lastOrNull()?.let { it in "@#/_.\\" || it.isDigit() } == true
        if (!inMiddle && !glued) {
            val fix = autoFix(w, lw)
            if (fix != null) {
                val out = finalCase(w, fix)
                if (out != w) {
                    ic.deleteSurroundingText(w.length, 0); ic.commitText(out, 1)
                    record(prevText, out)
                    return Pair(w, out + boundary)
                }
            }
        }
        learnWord(lw)
        record(prevText, w)
        return null
    }

    private fun setSug(l: String, c: String, r: String, quoteFirst: Boolean = false) {
        sugText[0] = l; sugText[1] = c; sugText[2] = r
        sugViews[0].text = if (quoteFirst && l.isNotEmpty()) "“$l”" else l
        sugViews[1].text = c; sugViews[2].text = r
    }

    private fun nextWords(prev: String): List<String> {
        val out = LinkedHashSet<String>()
        bigram[prev]?.entries?.sortedByDescending { it.value }?.forEach { out.add(it.key) }
        NEXT[prev]?.forEach { out.add(it.lowercase()) }
        if (prev.isEmpty()) out.addAll(listOf("i", "the", "i'm")) else out.addAll(listOf("the", "a", "to", "and", "i"))
        val cap = shift > 0
        return out.filter { it.isNotBlank() }.take(3).map { show(it, cap) }
    }

    private fun updateSuggestions() {
        if (listening) return
        val ic = currentInputConnection
        if (!suggestOn || ic == null) { wordMode = false; literal0 = false; setSug("", "", ""); return }
        val before = ic.getTextBeforeCursor(60, 0)?.toString() ?: ""
        val w = before.takeLastWhile { it.isLetter() || it == '\'' }
        if (w.isEmpty()) {
            wordMode = false; literal0 = false
            val n = nextWords(prevWord(before))
            setSug(n.getOrElse(0) { "" }, n.getOrElse(1) { "" }, n.getOrElse(2) { "" })
            return
        }
        wordMode = true
        val lw = w.lowercase()
        val prev = prevWord(before.dropLast(w.length))
        val isKnown = known(lw)
        val corr = if (!isKnown) corrections(lw, 3) else emptyList()
        val merged = LinkedHashSet<String>()
        FIXES[lw]?.let { merged.add(it.lowercase()) }
        corr.firstOrNull()?.let { merged.add(it) }
        merged.addAll(completions(lw, prev, 4))
        merged.addAll(corr)
        val list = merged.filter { it != lw }.map { finalCase(w, it) }
        if (isKnown && list.isEmpty()) { literal0 = false; setSug("", w, ""); return }
        literal0 = true
        setSug(w, list.getOrElse(0) { w }, list.getOrElse(1) { "" }, !isKnown)
    }

    private fun pick(i: Int) {
        if (listening) return
        val s = sugText[i]; if (s.isEmpty()) return
        val ic = currentInputConnection ?: return
        val before = ic.getTextBeforeCursor(60, 0)?.toString() ?: ""
        val w = before.takeLastWhile { it.isLetter() || it == '\'' }
        val prevText = before.dropLast(w.length)
        if (wordMode && i == 0 && literal0) {
            if (!known(w.lowercase())) learnWord(w.lowercase(), true)
            record(prevText, w)
            ic.commitText(" ", 1)
        } else {
            if (wordMode) ic.deleteSurroundingText(w.length, 0)
            ic.commitText("$s ", 1)
            record(if (wordMode) prevText else before, s)
        }
        undo = null; afterEdit()
    }

    // ---------- emoji ----------
    private fun buildEmoji() {
        emojiPanel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; visibility = View.GONE }
        val tabs = LinearLayout(this).apply { layoutParams = LinearLayout.LayoutParams(-1, dp(40)) }
        EMOJI.forEachIndexed { i, tab ->
            val tv = KeyView(this).apply {
                ic(tab.icon, 22)
                layoutParams = LinearLayout.LayoutParams(0, -1, 1f).apply { setMargins(dp(2), dp(2), dp(2), dp(2)) }
                setOnClickListener { tick(1); showEmoji(i) }
            }
            tabViews.add(tv); tabs.addView(tv)
        }
        tabs.addView(repeatKey(R.drawable.ic_backspace, 1.2f) { backspace() })
        emojiGrid = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        emojiPanel.addView(tabs)
        emojiPanel.addView(ScrollView(this).apply {
            layoutParams = LinearLayout.LayoutParams(-1, 0, 1f); addView(emojiGrid)
        })
        showEmoji(if (recents.isEmpty()) 1 else 0)
    }

    private fun showEmoji(i: Int) {
        tabViews.forEachIndexed { n, tv -> tv.background = if (n == i) glass(70, 10) else null }
        emojiGrid.removeAllViews()
        val list: List<String> = if (i == 0) recents else EMOJI[i].items.split(" ")
        if (list.isEmpty()) { emojiGrid.addView(note("Emojis you use will show up here.")); return }
        for (chunk in list.chunked(8)) {
            val r = LinearLayout(this).apply { layoutParams = LinearLayout.LayoutParams(-1, dp(46)) }
            for (e in chunk) r.addView(TextView(this).apply {
                text = e; textSize = 24f; gravity = Gravity.CENTER
                layoutParams = LinearLayout.LayoutParams(0, -1, 1f)
                setOnClickListener { tick(0); addEmoji(e) }
            })
            repeat(8 - chunk.size) { r.addView(gap(1f)) }
            emojiGrid.addView(r)
        }
    }

    private fun addEmoji(e: String) {
        currentInputConnection?.commitText(e, 1); undo = null
        recents.remove(e); recents.add(0, e); while (recents.size > 32) recents.removeAt(recents.size - 1)
        prefs.edit().putString("recents", recents.joinToString(" ")).apply()
        updateSuggestions()
    }

    // ---------- clipboard ----------
    private fun buildClip() {
        clipPanel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; visibility = View.GONE }
        val head = LinearLayout(this).apply { layoutParams = LinearLayout.LayoutParams(-1, dp(40)); gravity = Gravity.CENTER_VERTICAL }
        head.addView(TextView(this).apply {
            text = "Clipboard · tap to paste, hold to remove"; setTextColor(0xCCFFFFFF.toInt()); textSize = 13f
            setPadding(dp(10), 0, 0, 0); layoutParams = LinearLayout.LayoutParams(0, -1, 1f); gravity = Gravity.CENTER_VERTICAL
        })
        head.addView(TextView(this).apply {
            text = "Clear"; setTextColor(Color.WHITE); textSize = 14f; gravity = Gravity.CENTER
            background = keyBg(30, 14); setPadding(dp(14), 0, dp(14), 0)
            layoutParams = LinearLayout.LayoutParams(-2, dp(32)).apply { rightMargin = dp(6) }
            setOnClickListener { clips.clear(); saveClips(); refreshClips() }
        })
        clipList = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        clipPanel.addView(head)
        clipPanel.addView(ScrollView(this).apply { layoutParams = LinearLayout.LayoutParams(-1, 0, 1f); addView(clipList) })
    }

    private fun readClip() {
        try {
            val t = cm.primaryClip?.getItemAt(0)?.coerceToText(this)?.toString()?.trim()
            if (!t.isNullOrEmpty() && t != clips.firstOrNull()) {
                clips.remove(t); clips.add(0, t); while (clips.size > 30) clips.removeAt(clips.size - 1)
                saveClips(); if (mode == 2) refreshClips()
            }
        } catch (_: Exception) { }
    }

    private fun saveClips() = prefs.edit().putString("clips", clips.joinToString("\u0001")).apply()

    private fun refreshClips() {
        clipList.removeAllViews()
        if (clips.isEmpty()) { clipList.addView(note("Copy some text and it will show up here.")); return }
        for (c in clips) clipList.addView(TextView(this).apply {
            text = c; maxLines = 2; ellipsize = TextUtils.TruncateAt.END; setTextColor(Color.WHITE); textSize = 15f
            setPadding(dp(14), dp(10), dp(14), dp(10)); background = keyBg(30, 12)
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { setMargins(dp(4), dp(3), dp(4), dp(3)) }
            setOnClickListener { tick(0); currentInputConnection?.commitText(c, 1); undo = null; afterEdit(); setMode(0) }
            setOnLongClickListener { clips.remove(c); saveClips(); refreshClips(); true }
        })
    }

    // ---------- translate ----------
    private fun buildTranslate() {
        transPanel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; visibility = View.GONE }
        val chips = LinearLayout(this)
        for ((name, code) in LANGS) {
            val tv = TextView(this).apply {
                text = name; setTextColor(Color.WHITE); textSize = 14f; gravity = Gravity.CENTER
                setPadding(dp(14), 0, dp(14), 0)
                layoutParams = LinearLayout.LayoutParams(-2, dp(32)).apply { setMargins(dp(3), dp(4), dp(3), dp(4)) }
                setOnClickListener { selectLang(code) }
            }
            chipViews.add(tv to code); chips.addView(tv)
        }
        transPanel.addView(HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false; layoutParams = LinearLayout.LayoutParams(-1, dp(40)); addView(chips)
        })
        srcView = TextView(this).apply {
            setTextColor(0xAAFFFFFF.toInt()); textSize = 13f; maxLines = 1; ellipsize = TextUtils.TruncateAt.START
            setPadding(dp(10), dp(2), dp(10), dp(2))
        }
        resultView = TextView(this).apply {
            setTextColor(Color.WHITE); textSize = 17f; setPadding(dp(12), dp(8), dp(12), dp(8))
        }
        transPanel.addView(srcView)
        transPanel.addView(ScrollView(this).apply {
            background = glass(26, 12)
            layoutParams = LinearLayout.LayoutParams(-1, 0, 1f).apply { setMargins(dp(4), dp(2), dp(4), dp(2)) }
            addView(resultView)
        })
        val btns = LinearLayout(this).apply { layoutParams = LinearLayout.LayoutParams(-1, dp(46)) }
        btns.addView(key("Translate", 1f, 16f, true) { doTranslate() })
        btns.addView(key("Replace text", 1f, 16f) {
            val ic = currentInputConnection
            if (transResult.isNotEmpty() && ic != null) {
                if (!transSelected) ic.deleteSurroundingText(transSrcLen, 0)
                ic.commitText(transResult, 1); undo = null; setMode(0); afterEdit()
            }
        })
        transPanel.addView(btns)
        selectLang(targetLang)
    }

    private fun selectLang(code: String) {
        targetLang = code
        for ((tv, c) in chipViews) tv.background = if (c == code) accent(0xCC, 16) else glass(30, 16)
    }

    private fun grabSource(): String {
        val ic = currentInputConnection ?: return ""
        val sel = ic.getSelectedText(0)?.toString()
        if (!sel.isNullOrEmpty()) { transSelected = true; transSrcLen = sel.length; return sel }
        transSelected = false
        val t = ic.getTextBeforeCursor(500, 0)?.toString() ?: ""
        transSrcLen = t.length
        return t
    }

    private fun doTranslate() {
        val src = grabSource().trim()
        srcView.text = src.takeLast(80)
        if (src.isEmpty()) { resultView.text = "Type something in the text box first, then tap Translate."; return }
        resultView.text = "Translating…"; transResult = ""
        val lang = targetLang
        thread {
            val out = try {
                val url = URL("https://api.mymemory.translated.net/get?q=" + URLEncoder.encode(src, "UTF-8") + "&langpair=Autodetect%7C" + lang)
                val con = url.openConnection() as HttpURLConnection
                con.connectTimeout = 8000; con.readTimeout = 8000
                val body = con.inputStream.bufferedReader().use { it.readText() }
                val t = JSONObject(body).getJSONObject("responseData").getString("translatedText")
                Html.fromHtml(t, Html.FROM_HTML_MODE_LEGACY).toString()
            } catch (e: Exception) { null }
            ui.post {
                if (out == null) resultView.text = "Couldn't translate. Check your connection and try again."
                else { transResult = out; resultView.text = out }
            }
        }
    }

    // ---------- voice typing ----------
    private fun toggleVoice() {
        if (listening) { stopVoice(); return }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            startActivity(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK).putExtra("ask_mic", true))
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            Toast.makeText(this, "Speech recognition isn't available on this device", Toast.LENGTH_SHORT).show(); return
        }
        toolsOpen = false; showTools()
        val sr = SpeechRecognizer.createSpeechRecognizer(this); speech = sr
        sr.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(p: Bundle?) { setSug("", "Listening…", "") }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(v: Float) {}
            override fun onBufferReceived(b: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onEvent(t: Int, p: Bundle?) {}
            override fun onPartialResults(p: Bundle?) {
                val t = p?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                if (!t.isNullOrEmpty()) setSug("", t.takeLast(40), "")
            }
            override fun onResults(r: Bundle?) {
                val t = r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                if (!t.isNullOrEmpty()) {
                    val out = if (shift > 0) t.replaceFirstChar { it.uppercase() } else t
                    currentInputConnection?.commitText("$out ", 1); undo = null
                }
                stopVoice(); afterEdit()
            }
            override fun onError(e: Int) {
                if (e == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS)
                    startActivity(Intent(this@GlassKeyboardService, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK).putExtra("ask_mic", true))
                stopVoice()
            }
        })
        listening = true; micBtn.ic(R.drawable.ic_stop, 24)
        sr.startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault().toLanguageTag()))
    }

    private fun stopVoice() {
        val was = listening
        listening = false
        speech?.destroy(); speech = null
        if (::micBtn.isInitialized) micBtn.ic(R.drawable.ic_mic, 24)
        if (was && ::suggestRow.isInitialized) updateSuggestions()
    }
}
