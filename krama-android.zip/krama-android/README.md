# Krama — tasks, habits, stats

A small Android app for the two things people actually track: what you have to
do, and what you want to keep doing.

**Krama** (क्रम) is Sanskrit for *step, order, sequence* — which is what a task
list and a streak both are.

Kotlin, Jetpack Compose, no chart library, no database, **no permissions at
all**. Everything stays on the phone.

---

## Get the APK

The build workflow is **not** inside this folder — it ships separately as
`krama-build-apk.yml`, so there is exactly one copy to maintain.

1. Put this folder (or the zip) in a GitHub repo.
2. Add the workflow file at `.github/workflows/build-apk.yml`.
3. Push.

The **Actions** tab then gives you a `krama-debug-apk` artifact — a signed debug
APK you can install straight away. No Android Studio, no Play Store.

`git tag v1.0.0 && git push --tags` also attaches the APK to a GitHub Release.

That workflow handles both layouts: a repo containing `krama-android.zip` gets it
unpacked and built, and a repo containing the extracted folder is built in place.

Building locally needs JDK 17 and the Android SDK:

```bash
gradle test          # stats maths, on the JVM
gradle assembleDebug # app/build/outputs/apk/debug/app-debug.apk
```

---

## What it does

**Tasks** — add with a title, a due date and a priority. Tap any row to edit it.
Tick to complete; completed tasks sink to the bottom and grey out. Overdue items
turn ember. Delete via the × on each row.

Due dates are None / Today / Tomorrow, plus **Pick…** which opens a real calendar
picker — so any date is reachable, and the chosen day shows on the chip as
`12 Nov`.

**Habits** — add a habit with a weekly target of 3 to 7 days and a colour. Tap
the card to edit its name, target or colour. Each card shows a seven-day strip
you tap to mark a day done, the current streak, and progress against the
weekly target. Today not being ticked yet does not break a streak —
it only counts backwards from yesterday.

**Stats** — three independent toggles:

| Toggle | Options |
|---|---|
| What to measure | Habits · Tasks |
| How to draw it | Pie · Line · Donut |
| Over what period | 7 days · 30 days · 90 days |

Habits show the share of check-ins per habit; Tasks show completed versus
pending. The line chart plots one point per day across the chosen range. A
legend under the pie and donut gives each slice its count and percentage.

---

## Structure

```
app/src/main/java/in/krama/app/
├── MainActivity.kt          Compose host
├── KramaViewModel.kt        state + all mutations
├── data/
│   ├── Models.kt            Task, Habit, date helpers, streak + countIn
│   ├── Store.kt             JSON in SharedPreferences
│   └── Stats.kt             slice and line maths — pure, no Android
└── ui/
    ├── Root.kt              header, tab pills, screen switch
    ├── Screens.kt           Tasks + Habits + their dialogs
    ├── StatsScreen.kt       the three toggles and the chart wiring
    ├── Charts.kt            Pie, Donut, Line drawn on a Canvas
    └── Theme.kt             warm paper palette, shared slice colours
```

**No database.** A personal task list is a few kilobytes, so both lists are two
JSON blobs in SharedPreferences. That avoids Room's annotation processor and
schema migrations entirely — for this size of data it is the right trade.

**No chart library.** `Charts.kt` draws arcs and paths straight onto a Compose
`Canvas`. Labels live outside the canvas as ordinary `Text`, so nothing needs
text measurement — that is the usual source of chart-drawing bugs.

**Stats maths is pure Kotlin.** `Stats.kt` and the streak helpers in `Models.kt`
have no Android imports, which is why `gradle test` can check them on the JVM in
milliseconds.

---

## Tests

```bash
gradle test
```

`StatsTest.kt` covers streaks (consecutive days, an unfinished today, a gap),
windowed counts, done-versus-pending slices, empty states, and that the line
chart produces exactly one point per day in the range.

---

## Limits, honestly

- **Not compiled here.** The environment I built this in has no JDK or Android
  SDK. The first CI run is the real compile; the workflow prints file and line.
- **No reminders or notifications.** That needs `POST_NOTIFICATIONS` and an
  alarm service; this build asks for zero permissions and stays that way.
- **No reordering.** Tasks sort by done, then priority, then due date. Drag to
  reorder is not wired up.
- **Data lives in app storage.** Uninstalling clears it. There is no export.

---

## License

MIT.
