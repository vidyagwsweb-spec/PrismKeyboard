package `in`.krama.app.data

import java.time.LocalDate

data class Slice(val label: String, val value: Int)

data class Point(val label: String, val value: Int)

/**
 * Chart maths, kept pure and Android-free so it can be unit tested on the JVM.
 */
object Stats {

    /** Share of completions per habit inside the range. */
    fun habitSlices(habits: List<Habit>, range: Int): List<Slice> =
        habits.map { Slice(it.name, it.countIn(range)) }
            .filter { it.value > 0 }
            .sortedByDescending { it.value }

    /** Done versus still open. */
    fun taskSlices(tasks: List<Task>): List<Slice> {
        if (tasks.isEmpty()) return emptyList()
        val done = tasks.count { it.done }
        val open = tasks.size - done
        return buildList {
            if (done > 0) add(Slice("Completed", done))
            if (open > 0) add(Slice("Pending", open))
        }
    }

    /** How many habits were ticked on each of the last [range] days. */
    fun habitLine(habits: List<Habit>, range: Int): List<Point> {
        val today = LocalDate.now()
        return (range - 1 downTo 0).map { back ->
            val d = today.minusDays(back.toLong())
            val key = Dates.iso(d)
            Point(Dates.shortLabel(d), habits.count { key in it.days })
        }
    }

    /** How many tasks were completed on each of the last [range] days. */
    fun taskLine(tasks: List<Task>, range: Int): List<Point> {
        val today = LocalDate.now()
        return (range - 1 downTo 0).map { back ->
            val d = today.minusDays(back.toLong())
            val key = Dates.iso(d)
            Point(Dates.shortLabel(d), tasks.count { it.doneOn == key })
        }
    }

    /** Weekday initials for the habit strip, oldest first. */
    fun lastSevenDays(): List<LocalDate> {
        val today = LocalDate.now()
        return (6 downTo 0).map { today.minusDays(it.toLong()) }
    }
}
