package `in`.krama.app.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

// Warm paper and ink, same family as Yantra.
val Paper = Color(0xFFF5F2EC)
val SurfaceLight = Color(0xFFFFFFFF)
val Ink = Color(0xFF1B1815)
val Ink2 = Color(0xFF6B625A)
val LineLight = Color(0x1F1B1815)
val Ember = Color(0xFFE8622A)
val Amber = Color(0xFFF6B955)
val Sky = Color(0xFF8FB0C4)
val Clay = Color(0xFFD4622B)
val Plum = Color(0xFF5C2A22)
val Moss = Color(0xFF6F8F63)
val Rose = Color(0xFFC16C7A)

val PaperDark = Color(0xFF0A0807)
val SurfaceDark = Color(0xFF161412)
val InkDark = Color(0xFFF6F0E8)
val Ink2Dark = Color(0xFFB3A89C)
val LineDark = Color(0x1FFFFFFF)

/** Slice colours, reused by every chart so a habit keeps its colour. */
val ChartColours = listOf(Ember, Amber, Sky, Clay, Plum, Moss, Rose)

private val LightScheme = lightColorScheme(
    primary = Ember,
    onPrimary = Color.White,
    secondary = Amber,
    onSecondary = Ink,
    background = Paper,
    onBackground = Ink,
    surface = SurfaceLight,
    onSurface = Ink,
    surfaceVariant = Color(0xFFEFEAE1),
    onSurfaceVariant = Ink2,
    outline = LineLight,
    error = Clay,
    onError = Color.White
)

private val DarkScheme = darkColorScheme(
    primary = Ember,
    onPrimary = Color.White,
    secondary = Amber,
    onSecondary = Color(0xFF14100D),
    background = PaperDark,
    onBackground = InkDark,
    surface = SurfaceDark,
    onSurface = InkDark,
    surfaceVariant = Color(0xFF1C1713),
    onSurfaceVariant = Ink2Dark,
    outline = LineDark,
    error = Clay,
    onError = Color.White
)

private val KramaType = Typography(
    headlineMedium = TextStyle(
        fontWeight = FontWeight.Bold, fontSize = 28.sp, lineHeight = 32.sp, letterSpacing = (-0.8).sp
    ),
    titleLarge = TextStyle(
        fontWeight = FontWeight.SemiBold, fontSize = 18.sp, lineHeight = 24.sp, letterSpacing = (-0.3).sp
    ),
    titleMedium = TextStyle(
        fontWeight = FontWeight.SemiBold, fontSize = 15.sp, lineHeight = 20.sp
    ),
    bodyLarge = TextStyle(fontWeight = FontWeight.Normal, fontSize = 16.sp, lineHeight = 24.sp),
    bodyMedium = TextStyle(fontWeight = FontWeight.Normal, fontSize = 14.sp, lineHeight = 20.sp),
    labelLarge = TextStyle(fontWeight = FontWeight.SemiBold, fontSize = 14.sp, lineHeight = 18.sp),
    labelMedium = TextStyle(fontWeight = FontWeight.Medium, fontSize = 12.sp, lineHeight = 16.sp)
)

@Composable
fun KramaTheme(dark: Boolean, content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = if (dark) DarkScheme else LightScheme,
        typography = KramaType,
        content = content
    )
}
