package `in`.krama.app.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp
import `in`.krama.app.data.Point
import kotlin.math.min

/**
 * Charts drawn straight onto a Canvas — no chart library, no extra dependency.
 * Labels live outside the canvas as ordinary Text so nothing needs measuring.
 */

private fun total(values: List<Int>): Int = values.sum().coerceAtLeast(1)

@Composable
fun PieChart(values: List<Int>, colours: List<Color>, modifier: Modifier = Modifier) {
    Canvas(modifier) {
        if (values.isEmpty()) return@Canvas
        val r = min(size.width, size.height) / 2f
        val box = Size(r * 2f, r * 2f)
        val topLeft = Offset((size.width - box.width) / 2f, (size.height - box.height) / 2f)
        val sum = total(values)
        var start = -90f
        values.forEachIndexed { i, v ->
            val sweep = v.toFloat() / sum * 360f
            if (sweep > 0f) {
                drawArc(
                    color = colours[i % colours.size],
                    startAngle = start,
                    sweepAngle = sweep - 1.5f,
                    useCenter = true,
                    topLeft = topLeft,
                    size = box
                )
            }
            start += sweep
        }
    }
}

@Composable
fun DonutChart(values: List<Int>, colours: List<Color>, modifier: Modifier = Modifier) {
    Canvas(modifier) {
        if (values.isEmpty()) return@Canvas
        val r = min(size.width, size.height) / 2f
        val stroke = r * 0.46f
        val outer = r - stroke / 2f
        val box = Size(outer * 2f, outer * 2f)
        val topLeft = Offset((size.width - box.width) / 2f, (size.height - box.height) / 2f)
        val sum = total(values)
        var start = -90f
        values.forEachIndexed { i, v ->
            val sweep = v.toFloat() / sum * 360f
            if (sweep > 0f) {
                drawArc(
                    color = colours[i % colours.size],
                    startAngle = start,
                    sweepAngle = sweep - 1.5f,
                    useCenter = false,
                    topLeft = topLeft,
                    size = box,
                    style = Stroke(width = stroke, cap = StrokeCap.Butt)
                )
            }
            start += sweep
        }
    }
}

@Composable
fun LineChart(
    points: List<Point>,
    colour: Color,
    gridColour: Color,
    modifier: Modifier = Modifier
) {
    Canvas(modifier) {
        if (points.isEmpty()) return@Canvas
        val w = size.width
        val h = size.height
        val maxV = (points.maxOfOrNull { it.value } ?: 0).coerceAtLeast(1)

        // horizontal guides
        for (i in 0..3) {
            val y = h * i / 3f
            drawLine(gridColour, Offset(0f, y), Offset(w, y), strokeWidth = 1f)
        }

        val stepX = if (points.size > 1) w / (points.size - 1).toFloat() else w
        fun xAt(i: Int) = if (points.size > 1) i * stepX else w / 2f
        fun yAt(v: Int) = h - (v.toFloat() / maxV) * (h * 0.92f) - h * 0.04f

        val path = Path()
        points.forEachIndexed { i, p ->
            val x = xAt(i)
            val y = yAt(p.value)
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        drawPath(
            path = path,
            color = colour,
            style = Stroke(width = 2.5.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round)
        )

        // dots, but only when there is room for them
        if (points.size <= 31) {
            points.forEachIndexed { i, p ->
                drawCircle(colour, radius = 3.dp.toPx(), center = Offset(xAt(i), yAt(p.value)))
            }
        }
    }
}

/** Empty-state placeholder shared by all three charts. */
@Composable
fun ChartPlaceholder(modifier: Modifier = Modifier) {
    Box(modifier.fillMaxSize())
}
