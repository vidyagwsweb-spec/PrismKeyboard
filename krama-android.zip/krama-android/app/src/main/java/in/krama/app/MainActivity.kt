package `in`.krama.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import `in`.krama.app.ui.KramaRoot
import `in`.krama.app.ui.KramaTheme

class MainActivity : ComponentActivity() {

    private val vm: KramaViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            // called in the composable scope, not inside the state lambda
            val systemDark = isSystemInDarkTheme()
            var dark by rememberSaveable { mutableStateOf(systemDark) }
            KramaTheme(dark = dark) {
                KramaRoot(vm = vm, dark = dark, onToggleTheme = { dark = !dark })
            }
        }
    }
}
