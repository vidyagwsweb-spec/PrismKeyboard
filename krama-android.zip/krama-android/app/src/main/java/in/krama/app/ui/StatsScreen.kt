package `in`.krama.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import `in`.krama.app.KramaViewModel
import `in`.krama.app.data.Point
import `in`.krama.app.data.Slice
import `in`.krama.app.data.Stats

private const val METRIC_HABITS = 0
private const val METRIC_TASKS = 1

private const val CHART_PIE = 0
private const val CHART_LINE = 1
private const val CHART_DONUT = 2

@Composable
fun StatsScreen(vm: KramaViewModel, modifier: Modifier = Modifier) {
    val colors = MaterialTheme.colorScheme

    var metric by remember { mutableStateOf(METRIC_HABITS) }
    var chart by remember { mutableStateOf(CHART_DONUT) }
    var rangeIndex by remember { mutableStateOf(0) }
    val ranges = listOf(7, 30, 90)
    val range = ranges[rangeIndex]

    val slices: List<Slice> = remember(metric, range, vm.habits, vm.tasks) {
        if (metric == METRIC_HABITS) Stats.habitSlices(vm.habits, range)
        else Stats.taskSlices(vm.tasks)
    }
    val points: List<Point> = remember(metric, range, vm.habits, vm.tasks) {
        if (metric == METRIC_HABITS) Stats.habitLine(vm.habits, range)
        else Stats.taskLine(vm.tasks, range)
    }

    Column(
        modifier = modifier
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 8.dp)
    ) {
        // what to measure
        PillTabs(listOf("Habits", "Tasks"), metric) { metric = it }
        Spacer(Modifier.height(8.dp))

        // how to draw it
        PillTabs(listOf("Pie", "Line", "Donut"), chart) { chart = it }
        Spacer(Modifier.height(8.dp))

        // over what period
        PillTabs(listOf("7 days", "30 days", "90 days"), rangeIndex) { rangeIndex = it }

        Spacer(Modifier.height(18.dp))

        // headline number
        val headline = when {
            chart == CHART_LINE -> points.sumOf { it.value }
            else -> slices.sumOf { it.value }
        }
        val headlineLabel = when {
            metric == METRIC_HABITS && chart == CHART_LINE -> "habit check-ins"
            metric == METRIC_HABITS -> "check-ins"
            chart == CHART_LINE -> "tasks completed"
            else -> "tasks"
        }
        Row(verticalAlignment = Alignment.Bottom) {
            Text(
                text = headline.toString(),
                style = MaterialTheme.typography.headlineMedium,
                color = colors.onBackground,
                fontSize = 40.sp,
                fontWeight = FontWeight.Bold
            )
            Spacer(Modifier.width(8.dp))
            Text(
                text = headlineLabel,
                style = MaterialTheme.typography.labelMedium,
                color = colors.onSurfaceVariant,
                modifier = Modifier.padding(bottom = 8.dp)
            )
        }

        Spacer(Modifier.height(14.dp))

        // the chart
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(260.dp),
            contentAlignment = Alignment.Center
        ) {
            when {
                chart == CHART_LINE -> {
                    LineChart(
                        points = points,
                        colour = colors.primary,
                        gridColour = colors.outline,
                        modifier = Modifier.fillMaxSize()
                    )
                }
                slices.isEmpty() -> {
                    Text(
                        text = "Nothing logged in this period yet.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = colors.onSurfaceVariant
                    )
                }
                chart == CHART_PIE -> {
                    PieChart(
                        values = slices.map { it.value },
                        colours = ChartColours,
                        modifier = Modifier.size(240.dp)
                    )
                }
                else -> {
                    DonutChart(
                        values = slices.map { it.value },
                        colours = ChartColours,
                        modifier = Modifier.size(240.dp)
                    )
                }
            }
        }

        Spacer(Modifier.height(10.dp))

        // axis hints under the line chart
        if (chart == CHART_LINE && points.isNotEmpty()) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = points.first().label,
                    style = MaterialTheme.typography.labelMedium,
                    color = colors.onSurfaceVariant
                )
                Text(
                    text = points.last().label,
                    style = MaterialTheme.typography.labelMedium,
                    color = colors.onSurfaceVariant
                )
            }
            Spacer(Modifier.height(4.dp))
            Text(
                text = "peak ${points.maxOfOrNull { it.value } ?: 0} in a day",
                style = MaterialTheme.typography.labelMedium,
                color = colors.onSurfaceVariant
            )
        }

        // legend
        if (chart != CHART_LINE && slices.isNotEmpty()) {
            Spacer(Modifier.height(6.dp))
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                slices.forEachIndexed { i, slice ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(10.dp)
                                .clip(CircleShape)
                                .background(ChartColours[i % ChartColours.size])
                        )
                        Spacer(Modifier.width(10.dp))
                        Text(
                            text = slice.label,
                            style = MaterialTheme.typography.bodyMedium,
                            color = colors.onSurface,
                            modifier = Modifier.weight(1f)
                        )
                        val pct = if (headline > 0) slice.value * 100 / headline else 0
                        Text(
                            text = "${slice.value}  \u00b7  $pct%",
                            style = MaterialTheme.typography.labelMedium,
                            color = colors.onSurfaceVariant
                        )
                    }
                }
            }
        }

        Spacer(Modifier.height(28.dp))
    }
}
