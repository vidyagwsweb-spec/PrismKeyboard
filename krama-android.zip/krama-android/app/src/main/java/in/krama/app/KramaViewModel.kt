package `in`.krama.app

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import `in`.krama.app.data.Dates
import `in`.krama.app.data.Habit
import `in`.krama.app.data.Store
import `in`.krama.app.data.Task
import java.time.LocalDate

class KramaViewModel(app: Application) : AndroidViewModel(app) {

    private val store = Store(app)

    var tasks by mutableStateOf(store.loadTasks())
        private set

    var habits by mutableStateOf(store.loadHabits())
        private set

    // ------------------------------------------------------------------ tasks

    fun addTask(title: String, due: String, priority: Int) {
        val clean = title.trim()
        if (clean.isEmpty()) return
        tasks = tasks + Task(
            id = System.currentTimeMillis(),
            title = clean,
            due = due,
            priority = priority
        )
        store.saveTasks(tasks)
    }

    fun toggleTask(id: Long) {
        tasks = tasks.map { t ->
            if (t.id != id) t
            else t.copy(
                done = !t.done,
                doneOn = if (t.done) "" else Dates.iso(LocalDate.now())
            )
        }
        store.saveTasks(tasks)
    }

    fun updateTask(id: Long, title: String, due: String, priority: Int) {
        val clean = title.trim()
        if (clean.isEmpty()) return
        tasks = tasks.map { t ->
            if (t.id != id) t else t.copy(title = clean, due = due, priority = priority)
        }
        store.saveTasks(tasks)
    }

    fun deleteTask(id: Long) {
        tasks = tasks.filterNot { it.id == id }
        store.saveTasks(tasks)
    }

    // ----------------------------------------------------------------- habits

    fun addHabit(name: String, target: Int, colour: Int) {
        val clean = name.trim()
        if (clean.isEmpty()) return
        habits = habits + Habit(
            id = System.currentTimeMillis(),
            name = clean,
            target = target.coerceIn(1, 7),
            colour = colour.coerceIn(0, 6)
        )
        store.saveHabits(habits)
    }

    fun toggleHabit(id: Long, date: LocalDate) {
        val key = Dates.iso(date)
        habits = habits.map { h ->
            if (h.id != id) h
            else h.copy(days = if (key in h.days) h.days - key else h.days + key)
        }
        store.saveHabits(habits)
    }

    fun updateHabit(id: Long, name: String, target: Int, colour: Int) {
        val clean = name.trim()
        if (clean.isEmpty()) return
        habits = habits.map { h ->
            if (h.id != id) h
            else h.copy(name = clean, target = target.coerceIn(1, 7), colour = colour)
        }
        store.saveHabits(habits)
    }

    fun deleteHabit(id: Long) {
        habits = habits.filterNot { it.id == id }
        store.saveHabits(habits)
    }
}
