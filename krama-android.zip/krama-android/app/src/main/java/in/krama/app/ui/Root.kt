package `in`.krama.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import `in`.krama.app.KramaViewModel

@Composable
fun KramaRoot(vm: KramaViewModel, dark: Boolean, onToggleTheme: () -> Unit) {
    val colors = MaterialTheme.colorScheme
    var tab by rememberSaveable { mutableStateOf(0) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(colors.background)
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        // header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(start = 20.dp, end = 12.dp, top = 18.dp, bottom = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text(
                    text = "Krama",
                    style = MaterialTheme.typography.headlineMedium,
                    color = colors.onBackground
                )
                Text(
                    text = when (tab) {
                        0 -> "${vm.tasks.count { !it.done }} open \u00b7 ${vm.tasks.count { it.done }} done"
                        1 -> "${vm.habits.size} habits"
                        else -> "your numbers"
                    },
                    style = MaterialTheme.typography.labelMedium,
                    color = colors.onSurfaceVariant
                )
            }
            Box(
                modifier = Modifier
                    .size(38.dp)
                    .clip(CircleShape)
                    .clickable { onToggleTheme() },
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = if (dark) "\u2600" else "\u263e",
                    fontSize = 16.sp,
                    color = colors.onSurface
                )
            }
        }

        // tabs
        Box(modifier = Modifier.padding(horizontal = 16.dp)) {
            PillTabs(listOf("Tasks", "Habits", "Stats"), tab) { tab = it }
        }

        Spacer(Modifier.width(4.dp))

        // content
        Box(Modifier.weight(1f)) {
            when (tab) {
                0 -> TasksScreen(vm, Modifier.fillMaxSize())
                1 -> HabitsScreen(vm, Modifier.fillMaxSize())
                else -> StatsScreen(vm, Modifier.fillMaxSize())
            }
        }
    }
}
