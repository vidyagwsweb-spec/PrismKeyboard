package `in`.krama.app.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/**
 * Persistence without a database.
 *
 * A personal task list is a few kilobytes, so two JSON blobs in
 * SharedPreferences are simpler and far less to go wrong than Room — no
 * annotation processor, no schema migration.
 */
class Store(context: Context) {

    private val sp = context.applicationContext
        .getSharedPreferences("krama", Context.MODE_PRIVATE)

    // ------------------------------------------------------------------ tasks

    fun loadTasks(): List<Task> {
        val raw = sp.getString(KEY_TASKS, null) ?: return emptyList()
        return runCatching {
            val arr = JSONArray(raw)
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                Task(
                    id = o.optLong("id"),
                    title = o.optString("title"),
                    done = o.optBoolean("done"),
                    due = o.optString("due"),
                    doneOn = o.optString("doneOn"),
                    priority = o.optInt("priority", 1),
                    created = o.optLong("created")
                )
            }
        }.getOrDefault(emptyList())
    }

    fun saveTasks(tasks: List<Task>) {
        val arr = JSONArray()
        tasks.forEach { t ->
            arr.put(
                JSONObject()
                    .put("id", t.id)
                    .put("title", t.title)
                    .put("done", t.done)
                    .put("due", t.due)
                    .put("doneOn", t.doneOn)
                    .put("priority", t.priority)
                    .put("created", t.created)
            )
        }
        sp.edit().putString(KEY_TASKS, arr.toString()).apply()
    }

    // ----------------------------------------------------------------- habits

    fun loadHabits(): List<Habit> {
        val raw = sp.getString(KEY_HABITS, null) ?: return emptyList()
        return runCatching {
            val arr = JSONArray(raw)
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                val dayArr = o.optJSONArray("days") ?: JSONArray()
                val days = (0 until dayArr.length()).map { dayArr.getString(it) }.toSet()
                Habit(
                    id = o.optLong("id"),
                    name = o.optString("name"),
                    target = o.optInt("target", 7),
                    colour = o.optInt("colour"),
                    days = days,
                    created = o.optLong("created")
                )
            }
        }.getOrDefault(emptyList())
    }

    fun saveHabits(habits: List<Habit>) {
        val arr = JSONArray()
        habits.forEach { h ->
            val days = JSONArray()
            h.days.sorted().forEach { days.put(it) }
            arr.put(
                JSONObject()
                    .put("id", h.id)
                    .put("name", h.name)
                    .put("target", h.target)
                    .put("colour", h.colour)
                    .put("days", days)
                    .put("created", h.created)
            )
        }
        sp.edit().putString(KEY_HABITS, arr.toString()).apply()
    }

    private companion object {
        const val KEY_TASKS = "tasks.v1"
        const val KEY_HABITS = "habits.v1"
    }
}
