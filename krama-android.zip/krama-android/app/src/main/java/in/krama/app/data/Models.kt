package `in`.krama.app.data

import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale

/** One-off things to do. */
data class Task(
    val id: Long,
    val title: String,
    val done: Boolean = false,
    /** ISO date (yyyy-MM-dd) or "" for no due date. */
    val due: String = "",
    /** ISO date the task was ticked, or "" if not done. */
    val doneOn: String = "",
    /** 0 low, 1 normal, 2 high. */
    val priority: Int = 1,
    val created: Long = System.currentTimeMillis()
)

/** Repeating things you want to keep doing. */
data class Habit(
    val id: Long,
    val name: String,
    /** Days per week you are aiming for. */
    val target: Int = 7,
    /** Colour index into Palette.chart. */
    val colour: Int = 0,
    /** ISO dates on which this habit was completed. */
    val days: Set<String> = emptySet(),
    val created: Long = System.currentTimeMillis()
)

object Dates {
    fun iso(d: LocalDate): String = d.toString()

    fun parse(s: String): LocalDate? =
        if (s.isEmpty()) null else runCatching { LocalDate.parse(s) }.getOrNull()

    fun today(): LocalDate = LocalDate.now()

    fun shortLabel(d: LocalDate): String = "${d.dayOfMonth}/${d.monthValue}"

    fun weekdayInitial(d: LocalDate): String =
        d.dayOfWeek.name.take(1)

    private val PRETTY: DateTimeFormatter = DateTimeFormatter.ofPattern("d MMM", Locale.ENGLISH)

    /** "2026-11-12" -> "12 Nov" */
    fun pretty(iso: String): String = parse(iso)?.format(PRETTY) ?: iso
}

/** Consecutive days up to today. Today not being ticked yet does not break it. */
fun Habit.streak(): Int {
    var d = LocalDate.now()
    if (Dates.iso(d) !in days) d = d.minusDays(1)
    var n = 0
    while (Dates.iso(d) in days) {
        n++
        d = d.minusDays(1)
    }
    return n
}

fun Habit.doneToday(): Boolean = Dates.iso(LocalDate.now()) in days

/** Completions inside the last [range] days. */
fun Habit.countIn(range: Int): Int {
    val from = LocalDate.now().minusDays((range - 1).toLong())
    return days.count { iso -> Dates.parse(iso)?.let { !it.isBefore(from) } == true }
}
