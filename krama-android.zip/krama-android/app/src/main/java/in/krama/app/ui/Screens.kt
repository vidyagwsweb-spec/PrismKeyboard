package `in`.krama.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DatePicker
import androidx.compose.material3.DatePickerDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberDatePickerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import `in`.krama.app.KramaViewModel
import `in`.krama.app.data.Dates
import `in`.krama.app.data.Habit
import `in`.krama.app.data.Stats
import `in`.krama.app.data.Task
import `in`.krama.app.data.countIn
import `in`.krama.app.data.doneToday
import `in`.krama.app.data.streak
import java.time.LocalDate

// --------------------------------------------------------------------- shared

@Composable
fun PillTabs(options: List<String>, selected: Int, onSelect: (Int) -> Unit) {
    val colors = MaterialTheme.colorScheme
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(50))
            .background(colors.surfaceVariant)
            .padding(4.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        options.forEachIndexed { i, label ->
            Box(
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(50))
                    .background(if (i == selected) colors.primary else Color.Transparent)
                    .clickable { onSelect(i) }
                    .padding(vertical = 9.dp, horizontal = 2.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = label,
                    style = MaterialTheme.typography.labelMedium,
                    color = if (i == selected) colors.onPrimary else colors.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
private fun FieldLabel(text: String) {
    Text(
        text = text,
        style = MaterialTheme.typography.labelMedium,
        color = MaterialTheme.colorScheme.onSurfaceVariant
    )
}

// ---------------------------------------------------------------------- tasks

@Composable
fun TasksScreen(vm: KramaViewModel, modifier: Modifier = Modifier) {
    var editing by remember { mutableStateOf<Task?>(null) }
    var adding by remember { mutableStateOf(false) }
    val colors = MaterialTheme.colorScheme

    val ordered = remember(vm.tasks) {
        vm.tasks.sortedWith(
            compareBy<Task> { it.done }
                .thenByDescending { it.priority }
                .thenBy { it.due.ifEmpty { "9999-12-31" } }
        )
    }

    Box(modifier) {
        LazyColumn(
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 96.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            if (ordered.isEmpty()) {
                item {
                    Text(
                        text = "No tasks yet. Tap + to add the first one.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = colors.onSurfaceVariant,
                        modifier = Modifier.padding(vertical = 32.dp)
                    )
                }
            }
            items(ordered, key = { it.id }) { task ->
                TaskRow(
                    task = task,
                    onToggle = { vm.toggleTask(task.id) },
                    onEdit = { editing = task },
                    onDelete = { vm.deleteTask(task.id) }
                )
            }
        }

        FloatingActionButton(
            onClick = { adding = true },
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(20.dp),
            containerColor = colors.primary,
            contentColor = colors.onPrimary
        ) {
            Text("+", fontSize = 24.sp, fontWeight = FontWeight.Light)
        }
    }

    if (adding) {
        TaskDialog(
            existing = null,
            onDismiss = { adding = false },
            onSave = { title, due, priority ->
                vm.addTask(title, due, priority)
                adding = false
            }
        )
    }

    editing?.let { task ->
        TaskDialog(
            existing = task,
            onDismiss = { editing = null },
            onSave = { title, due, priority ->
                vm.updateTask(task.id, title, due, priority)
                editing = null
            }
        )
    }
}

@Composable
private fun TaskRow(
    task: Task,
    onToggle: () -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit
) {
    val colors = MaterialTheme.colorScheme
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .background(colors.surface)
            .border(1.dp, colors.outline, RoundedCornerShape(18.dp))
            .clickable { onEdit() }
            .padding(horizontal = 14.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(24.dp)
                .clip(CircleShape)
                .background(if (task.done) colors.primary else Color.Transparent)
                .border(2.dp, if (task.done) colors.primary else colors.outline, CircleShape)
                .clickable { onToggle() },
            contentAlignment = Alignment.Center
        ) {
            if (task.done) Text("\u2713", fontSize = 13.sp, color = colors.onPrimary)
        }

        Spacer(Modifier.width(12.dp))

        Column(Modifier.weight(1f)) {
            Text(
                text = task.title,
                style = MaterialTheme.typography.bodyLarge,
                color = if (task.done) colors.onSurfaceVariant else colors.onSurface,
                textDecoration = if (task.done) TextDecoration.LineThrough else TextDecoration.None
            )
            if (task.due.isNotEmpty()) {
                val label = when (task.due) {
                    Dates.iso(LocalDate.now()) -> "Today"
                    Dates.iso(LocalDate.now().plusDays(1)) -> "Tomorrow"
                    else -> Dates.pretty(task.due)
                }
                Text(
                    text = label,
                    style = MaterialTheme.typography.labelMedium,
                    color = if (task.due < Dates.iso(LocalDate.now()) && !task.done) colors.error
                    else colors.onSurfaceVariant
                )
            }
        }

        Box(
            modifier = Modifier
                .size(32.dp)
                .clip(CircleShape)
                .clickable { onDelete() },
            contentAlignment = Alignment.Center
        ) {
            Text("\u00d7", fontSize = 18.sp, color = colors.onSurfaceVariant)
        }
    }
}

@Composable
private fun TaskDialog(
    existing: Task?,
    onDismiss: () -> Unit,
    onSave: (String, String, Int) -> Unit
) {
    var title by remember(existing?.id) { mutableStateOf(existing?.title ?: "") }
    var due by remember(existing?.id) { mutableStateOf(existing?.due ?: "") }
    var priority by remember(existing?.id) { mutableStateOf(existing?.priority ?: 1) }
    var showPicker by remember { mutableStateOf(false) }

    val todayIso = Dates.iso(LocalDate.now())
    val tomorrowIso = Dates.iso(LocalDate.now().plusDays(1))
    val isCustom = due.isNotEmpty() && due != todayIso && due != tomorrowIso

    // None / Today / Tomorrow / a picked date
    val options = listOf("", todayIso, tomorrowIso, if (isCustom) due else "PICK")
    val labels = listOf(
        "None",
        "Today",
        "Tomorrow",
        if (isCustom) Dates.pretty(due) else "Pick\u2026"
    )
    val selectedIndex = options.indexOf(due).let { if (it >= 0) it else 3 }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (existing == null) "New task" else "Edit task") },
        text = {
            Column {
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    placeholder = { Text("What needs doing?") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(14.dp))
                FieldLabel("Due")
                Spacer(Modifier.height(6.dp))
                PillTabs(labels, selectedIndex) { index ->
                    if (index == 3) showPicker = true else due = options[index]
                }
                Spacer(Modifier.height(14.dp))
                FieldLabel("Priority")
                Spacer(Modifier.height(6.dp))
                PillTabs(listOf("Low", "Normal", "High"), priority) { priority = it }
            }
        },
        confirmButton = {
            TextButton(onClick = { onSave(title, due, priority) }) {
                Text(if (existing == null) "Add" else "Save")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )

    if (showPicker) {
        CalendarDialog(
            initialIso = due,
            onPick = { picked ->
                due = picked
                showPicker = false
            },
            onDismiss = { showPicker = false }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun CalendarDialog(
    initialIso: String,
    onPick: (String) -> Unit,
    onDismiss: () -> Unit
) {
    val start = Dates.parse(initialIso) ?: LocalDate.now()
    val state = rememberDatePickerState(
        initialSelectedDateMillis = start.toEpochDay() * 86_400_000L
    )

    DatePickerDialog(
        onDismissRequest = onDismiss,
        confirmButton = {
            TextButton(onClick = {
                val ms = state.selectedDateMillis
                if (ms != null) onPick(Dates.iso(LocalDate.ofEpochDay(ms / 86_400_000L)))
                onDismiss()
            }) { Text("OK") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    ) {
        DatePicker(state = state)
    }
}

// --------------------------------------------------------------------- habits

@Composable
fun HabitsScreen(vm: KramaViewModel, modifier: Modifier = Modifier) {
    var adding by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<Habit?>(null) }
    val colors = MaterialTheme.colorScheme
    val week = remember { Stats.lastSevenDays() }

    Box(modifier) {
        LazyColumn(
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 96.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            if (vm.habits.isEmpty()) {
                item {
                    Text(
                        text = "No habits yet. Tap + to start one.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = colors.onSurfaceVariant,
                        modifier = Modifier.padding(vertical = 32.dp)
                    )
                }
            }
            items(vm.habits, key = { it.id }) { habit ->
                HabitCard(
                    habit = habit,
                    week = week,
                    onToggleDay = { day -> vm.toggleHabit(habit.id, day) },
                    onEdit = { editing = habit },
                    onDelete = { vm.deleteHabit(habit.id) }
                )
            }
        }

        FloatingActionButton(
            onClick = { adding = true },
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(20.dp),
            containerColor = colors.primary,
            contentColor = colors.onPrimary
        ) {
            Text("+", fontSize = 24.sp, fontWeight = FontWeight.Light)
        }
    }

    if (adding) {
        HabitDialog(
            existing = null,
            onDismiss = { adding = false },
            onSave = { name, target, colour ->
                vm.addHabit(name, target, colour)
                adding = false
            }
        )
    }

    editing?.let { habit ->
        HabitDialog(
            existing = habit,
            onDismiss = { editing = null },
            onSave = { name, target, colour ->
                vm.updateHabit(habit.id, name, target, colour)
                editing = null
            }
        )
    }
}

@Composable
private fun HabitCard(
    habit: Habit,
    week: List<LocalDate>,
    onToggleDay: (LocalDate) -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit
) {
    val colors = MaterialTheme.colorScheme
    val accent = ChartColours[habit.colour % ChartColours.size]

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .background(colors.surface)
            .border(1.dp, colors.outline, RoundedCornerShape(20.dp))
            .clickable { onEdit() }
            .padding(16.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(10.dp)
                    .clip(CircleShape)
                    .background(accent)
            )
            Spacer(Modifier.width(10.dp))
            Text(
                text = habit.name,
                style = MaterialTheme.typography.titleMedium,
                color = colors.onSurface,
                modifier = Modifier.weight(1f)
            )
            val s = habit.streak()
            Text(
                text = if (s > 0) "$s day streak" else "no streak",
                style = MaterialTheme.typography.labelMedium,
                color = if (s > 0) accent else colors.onSurfaceVariant
            )
            Spacer(Modifier.width(6.dp))
            Box(
                modifier = Modifier
                    .size(28.dp)
                    .clip(CircleShape)
                    .clickable { onDelete() },
                contentAlignment = Alignment.Center
            ) {
                Text("\u00d7", fontSize = 16.sp, color = colors.onSurfaceVariant)
            }
        }

        Spacer(Modifier.height(14.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            week.forEach { day ->
                val done = Dates.iso(day) in habit.days
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = Dates.weekdayInitial(day),
                        style = MaterialTheme.typography.labelMedium,
                        color = colors.onSurfaceVariant
                    )
                    Spacer(Modifier.height(6.dp))
                    Box(
                        modifier = Modifier
                            .size(32.dp)
                            .clip(CircleShape)
                            .background(if (done) accent else Color.Transparent)
                            .border(1.5.dp, if (done) accent else colors.outline, CircleShape)
                            .clickable { onToggleDay(day) },
                        contentAlignment = Alignment.Center
                    ) {
                        if (done) Text("\u2713", fontSize = 13.sp, color = Color.White)
                    }
                }
            }
        }

        Spacer(Modifier.height(10.dp))

        Text(
            text = "${habit.countIn(7)} of ${habit.target} this week" +
                if (habit.doneToday()) " \u00b7 done today" else "",
            style = MaterialTheme.typography.labelMedium,
            color = colors.onSurfaceVariant
        )
    }
}

@Composable
private fun HabitDialog(
    existing: Habit?,
    onDismiss: () -> Unit,
    onSave: (String, Int, Int) -> Unit
) {
    var name by remember(existing?.id) { mutableStateOf(existing?.name ?: "") }
    var target by remember(existing?.id) { mutableStateOf(existing?.target ?: 6) }
    var colour by remember(existing?.id) { mutableStateOf(existing?.colour ?: 0) }
    val colors = MaterialTheme.colorScheme

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (existing == null) "New habit" else "Edit habit") },
        text = {
            Column {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    placeholder = { Text("e.g. Read 20 minutes") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(14.dp))
                FieldLabel("Days per week")
                Spacer(Modifier.height(6.dp))
                PillTabs(listOf("3", "4", "5", "6", "7"), (target - 3).coerceIn(0, 4)) {
                    target = it + 3
                }
                Spacer(Modifier.height(14.dp))
                FieldLabel("Colour")
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    ChartColours.forEachIndexed { i, c ->
                        Box(
                            modifier = Modifier
                                .size(26.dp)
                                .clip(CircleShape)
                                .background(c)
                                .border(
                                    width = if (i == colour) 2.dp else 0.dp,
                                    color = if (i == colour) colors.onSurface else Color.Transparent,
                                    shape = CircleShape
                                )
                                .clickable { colour = i }
                        )
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = { onSave(name, target, colour) }) {
                Text(if (existing == null) "Add" else "Save")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}
