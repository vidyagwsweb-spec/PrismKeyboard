package `in`.krama.app

import `in`.krama.app.data.Dates
import `in`.krama.app.data.Habit
import `in`.krama.app.data.Stats
import `in`.krama.app.data.Task
import `in`.krama.app.data.countIn
import `in`.krama.app.data.streak
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.LocalDate

/** Pure JVM tests: the stats maths has no Android imports. */
class StatsTest {

    private fun iso(daysAgo: Long): String = Dates.iso(LocalDate.now().minusDays(daysAgo))

    @Test
    fun streakCountsConsecutiveDays() {
        val h = Habit(id = 1, name = "Read", days = setOf(iso(0), iso(1), iso(2)))
        assertEquals(3, h.streak())
    }

    @Test
    fun streakSurvivesAnUnfinishedToday() {
        val h = Habit(id = 1, name = "Read", days = setOf(iso(1), iso(2)))
        assertEquals(2, h.streak())
    }

    @Test
    fun streakBreaksOnAGap() {
        val h = Habit(id = 1, name = "Read", days = setOf(iso(0), iso(2), iso(3)))
        assertEquals(1, h.streak())
    }

    @Test
    fun countInWindow() {
        val h = Habit(id = 1, name = "Read", days = setOf(iso(0), iso(3), iso(9), iso(40)))
        assertEquals(2, h.countIn(7))
        assertEquals(3, h.countIn(30))
    }

    @Test
    fun taskSlicesSplitDoneAndPending() {
        val tasks = listOf(
            Task(id = 1, title = "a", done = true),
            Task(id = 2, title = "b"),
            Task(id = 3, title = "c")
        )
        val slices = Stats.taskSlices(tasks)
        assertEquals(2, slices.size)
        assertEquals("Completed", slices[0].label)
        assertEquals(1, slices[0].value)
        assertEquals("Pending", slices[1].label)
        assertEquals(2, slices[1].value)
    }

    @Test
    fun taskSlicesAreEmptyWithNoTasks() {
        assertTrue(Stats.taskSlices(emptyList()).isEmpty())
    }

    @Test
    fun habitSlicesSkipHabitsWithNoCheckIns() {
        val a = Habit(id = 1, name = "Read", days = setOf(iso(0)))
        val b = Habit(id = 2, name = "Run", days = emptySet())
        val slices = Stats.habitSlices(listOf(a, b), 7)
        assertEquals(1, slices.size)
        assertEquals("Read", slices[0].label)
    }

    @Test
    fun prettyDateFormatting() {
        assertEquals("12 Nov", Dates.pretty("2026-11-12"))
        assertEquals("1 Jan", Dates.pretty("2027-01-01"))
        // anything unparseable is passed through rather than crashing
        assertEquals("", Dates.pretty(""))
        assertEquals("not-a-date", Dates.pretty("not-a-date"))
    }

    @Test
    fun lineHasOnePointPerDay() {
        assertEquals(7, Stats.habitLine(emptyList(), 7).size)
        assertEquals(30, Stats.taskLine(emptyList(), 30).size)
    }

    @Test
    fun taskLineCountsByCompletionDay() {
        val tasks = listOf(
            Task(id = 1, title = "a", done = true, doneOn = iso(0)),
            Task(id = 2, title = "b", done = true, doneOn = iso(0)),
            Task(id = 3, title = "c", done = true, doneOn = iso(2))
        )
        val line = Stats.taskLine(tasks, 7)
        assertEquals(2, line.last().value)          // today
        assertEquals(1, line[line.size - 3].value)  // two days ago
    }
}
